import React, { useMemo, useState } from 'react';
import {
  ArrowUpRight,
  ArrowDownLeft,
  ArrowRight,
  ArrowLeft,
  FileText,
  Calculator,
  Sparkles,
} from 'lucide-react';
import { Invoice, Language, NavView, TaxRuleConfig } from '../types';
import { getT } from '../i18n/translations';
import { formatDzd, formatMonthLabel, roundMoney } from '../utils/taxMath';

interface DashboardViewProps {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  invoices: Invoice[];
  taxRules: TaxRuleConfig[];
  onNavigate: (view: NavView) => void;
  onNewInvoice: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  lang,
  currencyDisplay,
  invoices,
  onNavigate,
  onNewInvoice,
}) => {
  const t = getT(lang);
  const [hoveredMonth, setHoveredMonth] = useState<string | null>(null);

  const metrics = useMemo(() => {
    const totalTaxes = invoices.reduce((acc, inv) => acc + inv.taxAmount, 0);
    const totalHT = invoices.reduce((acc, inv) => acc + inv.amountHT, 0);
    const totalTTC = invoices.reduce((acc, inv) => acc + inv.amountTTC, 0);
    const paidCount = invoices.filter((i) => i.status === 'paid').length;
    const pendingCount = invoices.filter((i) => i.status === 'pending').length;
    const draftCount = invoices.filter((i) => i.status === 'draft').length;

    return {
      totalTaxes: roundMoney(totalTaxes),
      totalHT: roundMoney(totalHT),
      totalTTC: roundMoney(totalTTC),
      count: invoices.length,
      paidCount,
      pendingCount,
      draftCount,
    };
  }, [invoices]);

  const monthlyData = useMemo(() => {
    const map = new Map<string, { month: string; ht: number; tax: number; ttc: number; count: number }>();
    invoices.forEach((inv) => {
      const ym = inv.date.slice(0, 7);
      const curr = map.get(ym) || { month: ym, ht: 0, tax: 0, ttc: 0, count: 0 };
      curr.ht = roundMoney(curr.ht + inv.amountHT);
      curr.tax = roundMoney(curr.tax + inv.taxAmount);
      curr.ttc = roundMoney(curr.ttc + inv.amountTTC);
      curr.count += 1;
      map.set(ym, curr);
    });
    return Array.from(map.values())
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-6);
  }, [invoices]);

  const categoryBreakdown = useMemo(() => {
    const map = new Map<string, { code: string; tax: number; ht: number; count: number }>();
    invoices.forEach((inv) => {
      const curr = map.get(inv.taxCode) || { code: inv.taxCode, tax: 0, ht: 0, count: 0 };
      curr.tax = roundMoney(curr.tax + inv.taxAmount);
      curr.ht = roundMoney(curr.ht + inv.amountHT);
      curr.count += 1;
      map.set(inv.taxCode, curr);
    });
    const total = metrics.totalTaxes || 1;
    return Array.from(map.values())
      .sort((a, b) => b.tax - a.tax)
      .map((item) => ({
        ...item,
        share: roundMoney((item.tax / total) * 100),
      }));
  }, [invoices, metrics.totalTaxes]);

  const recentInvoices = useMemo(() => {
    return [...invoices]
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 5);
  }, [invoices]);

  const maxMonthlyVal = useMemo(() => {
    const max = Math.max(...monthlyData.map((d) => Math.max(d.ht, d.tax)), 10000);
    return max * 1.15;
  }, [monthlyData]);

  const statusTextColor = (status: Invoice['status']) => {
    if (status === 'paid') return 'text-emerald-700 dark:text-emerald-400';
    if (status === 'pending') return 'text-[#B3861D] dark:text-[#E5C158]';
    return 'text-slate-500 dark:text-emerald-300/60';
  };

  return (
    <div className="space-y-6">
      {/* Homepage Welcome & Prominent Tax Calculator Spotlight */}
      <section className="rounded-2xl border border-[#DCE3DC] dark:border-[#174236] bg-white dark:bg-[#0A221B] overflow-hidden">
        <div className="h-1 w-full bg-gradient-to-r from-emerald-600 via-[#D4AF37] to-emerald-700" />
        <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Welcome Copy */}
          <div className="lg:col-span-7 space-y-3">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#063B2C] dark:text-white text-balance">
              {t.dashboard.welcomeTitle}
            </h2>
            <p className="text-base sm:text-lg font-medium text-emerald-800 dark:text-emerald-200 leading-relaxed">
              {t.dashboard.welcomeLine1}
            </p>
            <p className="text-sm text-slate-600 dark:text-emerald-200/80 leading-relaxed max-w-2xl">
              {t.dashboard.welcomeLine2}
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onNavigate('assistant')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-medium border border-[#DCE0D9] dark:border-[#1B493C] bg-[#F1F2EE] dark:bg-[#0E2B22] text-[#063B2C] dark:text-emerald-100 hover:border-[#C89B2B] dark:hover:border-[#E5C158] transition-colors whitespace-nowrap"
              >
                <Sparkles className="w-4 h-4 text-[#B3861D] dark:text-[#E5C158]" />
                <span>{t.nav.assistant}</span>
              </button>

              <button
                type="button"
                onClick={onNewInvoice}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-medium border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22] transition-colors whitespace-nowrap"
              >
                <FileText className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                <span>{t.actions.newInvoice}</span>
              </button>
            </div>
          </div>

          {/* Dominant Primary Action: Smart Tax Calculator Card */}
          <div className="lg:col-span-5 bg-[#052E22] dark:bg-[#062219] text-white rounded-xl p-6 border border-[#D4AF37]/40 flex flex-col justify-between space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1.5">
                <div className="text-xs font-medium text-[#E5C158]">
                  {t.dashboard.title}
                </div>
                <h3 className="text-lg font-bold text-white">
                  {t.dashboard.calculatorSpotTitle}
                </h3>
                <p className="text-xs sm:text-sm text-emerald-100/85 leading-relaxed">
                  {t.dashboard.calculatorSpotDesc}
                </p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-[#D4AF37]/45 flex items-center justify-center shrink-0">
                <Calculator className="w-5 h-5 text-[#E5C158]" />
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('calculator')}
              className="w-full inline-flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-xl text-sm sm:text-base font-bold bg-emerald-600 hover:bg-emerald-500 text-white border border-[#E5C158]/40 transition-colors shadow-sm"
            >
              <Calculator className="w-5 h-5 text-[#FDE68A]" />
              <span>{t.dashboard.startCalculatorCta}</span>
              {lang === 'ar' ? (
                <ArrowLeft className="w-4 h-4" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </section>

      {/* 4 Financial KPI Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-emerald-700 dark:bg-emerald-800 text-white rounded-xl p-5 border border-[#D4AF37]/40 flex flex-col justify-between">
          <div className="text-xs font-medium text-emerald-100">{t.dashboard.totalTaxes}</div>
          <div className="mt-3 text-2xl font-bold font-mono-num tracking-tight text-[#FDE68A]">
            {formatDzd(metrics.totalTaxes, lang, currencyDisplay)}
          </div>
          <div className="mt-3 text-xs text-emerald-100/90 flex items-center gap-2">
            <span className="font-mono-num font-semibold">
              {metrics.totalHT > 0
                ? `${roundMoney((metrics.totalTaxes / metrics.totalHT) * 100)}%`
                : '0%'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{lang === 'ar' ? 'متوسط العبء الضريبي الفعلي' : 'Effective avg. tax ratio'}</span>
          </div>
        </div>

        <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl p-5 border border-[#E0E3DD] dark:border-[#1B493C] flex flex-col justify-between">
          <div className="text-xs font-medium text-slate-600 dark:text-emerald-200/75">
            {t.dashboard.totalInvoices}
          </div>
          <div className="mt-3 text-2xl font-bold font-mono-num tracking-tight text-[#063B2C] dark:text-white">
            {metrics.count}
          </div>
          <div className="mt-3 text-xs text-slate-600 dark:text-emerald-200/75 flex items-center gap-2 flex-wrap">
            <span className="text-emerald-700 dark:text-emerald-400 font-semibold">
              {metrics.paidCount} {t.dashboard.paidCount}
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-[#B3861D] dark:text-[#E5C158] font-medium">
              {metrics.pendingCount} {t.dashboard.pendingCount}
            </span>
            <span aria-hidden="true">·</span>
            <span>
              {metrics.draftCount} {t.dashboard.draftCount}
            </span>
          </div>
        </div>

        <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl p-5 border border-[#E0E3DD] dark:border-[#1B493C] flex flex-col justify-between">
          <div className="text-xs font-medium text-slate-600 dark:text-emerald-200/75">
            {t.dashboard.taxableBase}
          </div>
          <div className="mt-3 text-2xl font-bold font-mono-num tracking-tight text-[#063B2C] dark:text-white">
            {formatDzd(metrics.totalHT, lang, currencyDisplay)}
          </div>
          <div className="mt-3 text-xs text-slate-600 dark:text-emerald-200/75">
            {lang === 'ar' ? 'مجموع الأساس قبل الضريبة' : 'Aggregate net excluding tax'}
          </div>
        </div>

        <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl p-5 border border-[#E0E3DD] dark:border-[#1B493C] flex flex-col justify-between">
          <div className="text-xs font-medium text-slate-600 dark:text-emerald-200/75">
            {t.dashboard.grossVolume}
          </div>
          <div className="mt-3 text-2xl font-bold font-mono-num tracking-tight text-[#063B2C] dark:text-white">
            {formatDzd(metrics.totalTTC, lang, currencyDisplay)}
          </div>
          <div className="mt-3 text-xs text-slate-600 dark:text-emerald-200/75">
            {lang === 'ar' ? 'الإجمالي شامل كل الرسوم' : 'Aggregate gross including tax'}
          </div>
        </div>
      </section>

      {/* Charts Row */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
            <div>
              <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
                {t.dashboard.monthlyChartTitle}
              </h3>
              <p className="text-xs text-slate-600 dark:text-emerald-200/70 mt-0.5">
                {t.dashboard.monthlyChartDesc}
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs shrink-0">
              <span className="inline-flex items-center gap-1.5 text-[#063B2C] dark:text-emerald-100">
                <span className="w-2.5 h-2.5 rounded-xs bg-emerald-700 dark:bg-emerald-500 inline-block" />
                {t.dashboard.legendHt}
              </span>
              <span className="inline-flex items-center gap-1.5 text-[#063B2C] dark:text-emerald-100">
                <span className="w-2.5 h-2.5 rounded-xs bg-[#D4AF37] inline-block" />
                {t.dashboard.legendTax}
              </span>
            </div>
          </div>

          {monthlyData.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center text-sm text-slate-500 dark:text-emerald-200/70 border border-dashed border-[#DCE0D9] dark:border-[#1B493C] rounded-lg p-6">
              <FileText className="w-8 h-8 text-emerald-600/60 mb-2" />
              <p>{t.dashboard.noData}</p>
            </div>
          ) : (
            <div className="relative h-64 flex items-end justify-between gap-3 sm:gap-5 pt-8 pb-2 px-1">
              <div className="absolute inset-x-0 top-8 bottom-8 flex flex-col justify-between pointer-events-none">
                {[0, 1, 2, 3].map((idx) => (
                  <div
                    key={idx}
                    className="border-b border-[#ECEEE9] dark:border-[#14392E] w-full"
                  />
                ))}
              </div>

              {monthlyData.map((d) => {
                const htPct = Math.max(4, (d.ht / maxMonthlyVal) * 100);
                const taxPct = Math.max(4, (d.tax / maxMonthlyVal) * 100);
                const isHovered = hoveredMonth === d.month;

                return (
                  <div
                    key={d.month}
                    onMouseEnter={() => setHoveredMonth(d.month)}
                    onMouseLeave={() => setHoveredMonth(null)}
                    className="relative flex-1 h-full flex flex-col items-center justify-end group"
                  >
                    {isHovered && (
                      <div className="absolute -top-3 z-20 bg-[#052E22] text-white text-[11px] rounded-lg px-3 py-2 shadow-lg border border-[#D4AF37]/50 whitespace-nowrap pointer-events-none">
                        <div className="font-semibold mb-1">{formatMonthLabel(d.month, lang)}</div>
                        <div className="font-mono-num text-emerald-200">
                          HT: {formatDzd(d.ht, lang, currencyDisplay)}
                        </div>
                        <div className="font-mono-num text-[#FDE68A]">
                          Tax: {formatDzd(d.tax, lang, currencyDisplay)}
                        </div>
                      </div>
                    )}

                    <div className="w-full max-w-[68px] flex-1 flex items-end justify-center gap-1.5 pb-2 relative z-10">
                      <div
                        style={{ height: `${htPct}%` }}
                        className="w-1/2 rounded-t-md bg-emerald-700 dark:bg-emerald-500 transition-all duration-200 group-hover:opacity-90"
                      />
                      <div
                        style={{ height: `${taxPct}%` }}
                        className="w-1/2 rounded-t-md bg-[#D4AF37] transition-all duration-200 group-hover:bg-[#E5C158]"
                      />
                    </div>
                    <span className="text-[11px] font-medium text-slate-600 dark:text-emerald-200/75 whitespace-nowrap pt-1">
                      {formatMonthLabel(d.month, lang)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Tax Breakdown Secondary Card */}
        <div className="lg:col-span-4 bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-5 sm:p-6 flex flex-col">
          <div>
            <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
              {t.dashboard.breakdownTitle}
            </h3>
            <p className="text-xs text-slate-600 dark:text-emerald-200/70 mt-0.5">
              {t.dashboard.breakdownDesc}
            </p>
          </div>

          <div className="mt-6 space-y-4 flex-1">
            {categoryBreakdown.length === 0 ? (
              <p className="text-sm text-slate-600 dark:text-emerald-200/70">{t.dashboard.noData}</p>
            ) : (
              categoryBreakdown.map((item, idx) => {
                const barColors = [
                  'bg-emerald-600',
                  'bg-[#C89B2B]',
                  'bg-emerald-800 dark:bg-emerald-400',
                  'bg-teal-600',
                  'bg-amber-600',
                ];
                return (
                  <div key={item.code} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-[#063B2C] dark:text-white">
                          {item.code}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-600 dark:text-emerald-200/75">
                          {item.count} {lang === 'ar' ? 'فواتير' : 'inv.'}
                        </span>
                      </div>
                      <div className="font-mono-num font-semibold text-[#063B2C] dark:text-emerald-100">
                        {formatDzd(item.tax, lang, currencyDisplay)} ({item.share}%)
                      </div>
                    </div>
                    <div className="h-2 rounded-full bg-white dark:bg-[#061A14] overflow-hidden border border-[#E0E3DD] dark:border-[#1B493C]">
                      <div
                        style={{ width: `${Math.min(100, Math.max(3, item.share))}%` }}
                        className={`h-full rounded-full transition-all duration-300 ${
                          barColors[idx % barColors.length]
                        }`}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="mt-6 w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:border-emerald-600 transition-colors"
          >
            <span>{t.nav.reports}</span>
            {lang === 'ar' ? <ArrowDownLeft className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
          </button>
        </div>
      </section>

      {/* Recent Transactions Table */}
      <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden">
        <div className="px-5 sm:px-6 py-4 border-b border-[#E3E6E0] dark:border-[#163D32] flex items-center justify-between gap-4">
          <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
            {t.dashboard.recentTitle}
          </h3>
          <button
            type="button"
            onClick={() => onNavigate('invoices')}
            className="text-xs font-semibold text-emerald-700 dark:text-[#E5C158] hover:underline whitespace-nowrap"
          >
            {t.dashboard.viewAllInvoices}
          </button>
        </div>

        {recentInvoices.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm text-slate-600 dark:text-emerald-200/70 mb-4">{t.dashboard.noData}</p>
            <button
              type="button"
              onClick={onNewInvoice}
              className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-600 text-white"
            >
              {t.actions.newInvoice}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/80 dark:bg-[#0E2B22] text-xs text-[#0A4A37] dark:text-emerald-200/80">
                  <th className="py-3 px-5 text-start font-semibold">{t.invoices.colNumber}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colClient}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colDate}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colTax}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTaxAmt}</th>
                  <th className="py-3 px-5 text-end font-semibold">{t.invoices.colTtc}</th>
                  <th className="py-3 px-5 text-start font-semibold">{t.invoices.colStatus}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
                {recentInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    className="hover:bg-[#FAF9F5] dark:hover:bg-[#0E2B22]/60 transition-colors"
                  >
                    <td className="py-3 px-5 font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-emerald-100 max-w-[220px] truncate">
                      {inv.clientName}
                    </td>
                    <td className="py-3 px-4 font-mono-num text-slate-600 dark:text-emerald-200/75 whitespace-nowrap">
                      {inv.date}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-emerald-100 whitespace-nowrap font-mono-num">
                      {inv.taxCode} · {inv.taxRate}%
                    </td>
                    <td className="py-3 px-4 text-end font-mono-num text-emerald-700 dark:text-emerald-400 font-semibold whitespace-nowrap">
                      {formatDzd(inv.taxAmount, lang, currencyDisplay)}
                    </td>
                    <td className="py-3 px-5 text-end font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                      {formatDzd(inv.amountTTC, lang, currencyDisplay)}
                    </td>
                    <td className={`py-3 px-5 font-semibold text-xs whitespace-nowrap ${statusTextColor(inv.status)}`}>
                      {t.invoices.statusLabels[inv.status]}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
