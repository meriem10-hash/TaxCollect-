import React, { useId } from 'react';

interface TaxCollectLogoProps {
  className?: string;
}

/**
 * Bespoke TaxCollect brand icon: deep emerald tile with subtle soft-gold framing
 * and a detailed ivory-white financial calculator with golden calculation accent.
 */
export const TaxCollectLogo: React.FC<TaxCollectLogoProps> = ({ className = 'w-9 h-9' }) => {
  const uid = useId().replace(/:/g, '');
  const bgId = `tcBg-${uid}`;
  const goldId = `tcGold-${uid}`;
  const ivoryId = `tcIvory-${uid}`;
  const keyId = `tcKey-${uid}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
      className={className}
      role="img"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={bgId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0A543E" />
          <stop offset="55%" stopColor="#053829" />
          <stop offset="100%" stopColor="#032118" />
        </linearGradient>
        <linearGradient id={goldId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F3D675" />
          <stop offset="50%" stopColor="#D4AF37" />
          <stop offset="100%" stopColor="#B3861D" />
        </linearGradient>
        <linearGradient id={ivoryId} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="#F2EFE6" />
        </linearGradient>
        <linearGradient id={keyId} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#074A36" />
          <stop offset="100%" stopColor="#052E22" />
        </linearGradient>
      </defs>

      {/* Deep Emerald App Tile */}
      <rect x="12" y="12" width="488" height="488" rx="112" ry="112" fill={`url(#${bgId})`} />

      {/* Subtle Soft Gold Inner Hairline Frame */}
      <rect
        x="26"
        y="26"
        width="460"
        height="460"
        rx="98"
        ry="98"
        fill="none"
        stroke={`url(#${goldId})`}
        strokeWidth="3"
        opacity="0.7"
      />

      {/* Depth Shadow */}
      <rect x="136" y="106" width="240" height="320" rx="34" ry="34" fill="#021710" opacity="0.48" />

      {/* Ivory White Calculator Body */}
      <rect
        x="136"
        y="94"
        width="240"
        height="320"
        rx="34"
        ry="34"
        fill={`url(#${ivoryId})`}
        stroke={`url(#${goldId})`}
        strokeWidth="3.5"
      />

      {/* Recessed Dark Emerald Display Screen */}
      <rect
        x="160"
        y="118"
        width="192"
        height="76"
        rx="16"
        ry="16"
        fill="#04261C"
        stroke="#0B5740"
        strokeWidth="2.5"
      />

      {/* Display Gold Indicator & Clean Readout Bars */}
      <rect x="176" y="136" width="32" height="6" rx="3" ry="3" fill={`url(#${goldId})`} opacity="0.88" />
      <rect x="234" y="162" width="76" height="12" rx="6" ry="6" fill="#FAF9F5" />
      <rect x="318" y="162" width="18" height="12" rx="6" ry="6" fill={`url(#${goldId})`} />

      {/* Row 1: Operator Keys (+, -, %) */}
      <rect x="160" y="214" width="54" height="48" rx="12" ry="12" fill={`url(#${keyId})`} />
      <rect x="229" y="214" width="54" height="48" rx="12" ry="12" fill={`url(#${keyId})`} />
      <rect x="298" y="214" width="54" height="48" rx="12" ry="12" fill="#059669" />

      <line x1="187" y1="229" x2="187" y2="247" stroke="#FAF9F5" strokeWidth="4.5" strokeLinecap="round" />
      <line x1="178" y1="238" x2="196" y2="238" stroke="#FAF9F5" strokeWidth="4.5" strokeLinecap="round" />
      <line x1="247" y1="238" x2="265" y2="238" stroke="#FAF9F5" strokeWidth="4.5" strokeLinecap="round" />

      <circle cx="318" cy="231" r="3.3" fill="#FAF9F5" />
      <line x1="332" y1="229" x2="318" y2="247" stroke="#FAF9F5" strokeWidth="4" strokeLinecap="round" />
      <circle cx="332" cy="245" r="3.3" fill="#FAF9F5" />

      {/* Row 2 & 3: Tactile Numeric Keys */}
      <rect x="160" y="278" width="54" height="48" rx="12" ry="12" fill="#E3E8E5" />
      <rect x="229" y="278" width="54" height="48" rx="12" ry="12" fill="#E3E8E5" />
      <rect x="160" y="342" width="54" height="48" rx="12" ry="12" fill="#E3E8E5" />
      <rect x="229" y="342" width="54" height="48" rx="12" ry="12" fill="#E3E8E5" />
      <circle cx="187" cy="302" r="5.2" fill="#063B2C" opacity="0.78" />
      <circle cx="256" cy="302" r="5.2" fill="#063B2C" opacity="0.78" />
      <circle cx="187" cy="366" r="5.2" fill="#063B2C" opacity="0.78" />
      <circle cx="256" cy="366" r="5.2" fill="#063B2C" opacity="0.78" />

      {/* Tall Soft Gold Equals Key */}
      <rect x="298" y="278" width="54" height="112" rx="14" ry="14" fill={`url(#${goldId})`} />
      <line x1="314" y1="327" x2="336" y2="327" stroke="#052E22" strokeWidth="5" strokeLinecap="round" />
      <line x1="314" y1="341" x2="336" y2="341" stroke="#052E22" strokeWidth="5" strokeLinecap="round" />
    </svg>
  );
};
