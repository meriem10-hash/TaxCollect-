import React, { useEffect, useRef, useState } from 'react';
import { Send, Bot, Trash2, Calculator, X, AlertCircle, RotateCcw } from 'lucide-react';
import { CalculatorSnapshot, ChatMessage, Language } from '../types';
import { getT } from '../i18n/translations';
import { formatDzd } from '../utils/taxMath';

interface AssistantViewProps {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  attachedContext: CalculatorSnapshot | null;
  onClearContext: () => void;
}

function renderFormattedText(text: string): React.ReactNode {
  const lines = text.split('\n');
  return lines.map((line, idx) => {
    const trimmed = line.trim();
    if (!trimmed) {
      return <div key={idx} className="h-2" />;
    }

    if (trimmed.startsWith('### ') || trimmed.startsWith('## ') || trimmed.startsWith('# ')) {
      const clean = trimmed.replace(/^#{1,3}\s+/, '');
      return (
        <h4 key={idx} className="font-bold text-sm sm:text-base text-[#063B2C] dark:text-[#FDE68A] mt-2 mb-1">
          {renderInlineBold(clean)}
        </h4>
      );
    }

    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      const clean = trimmed.slice(2);
      return (
        <div key={idx} className="flex items-start gap-2 ps-2 leading-relaxed">
          <span className="text-emerald-600 dark:text-[#E5C158] mt-1.5 text-[10px]">●</span>
          <span>{renderInlineBold(clean)}</span>
        </div>
      );
    }

    return (
      <p key={idx} className="leading-relaxed">
        {renderInlineBold(line)}
      </p>
    );
  });
}

function renderInlineBold(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={i} className="font-semibold text-[#063B2C] dark:text-white">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <React.Fragment key={i}>{part}</React.Fragment>;
  });
}

export const AssistantView: React.FC<AssistantViewProps> = ({
  lang,
  currencyDisplay,
  attachedContext,
  onClearContext,
}) => {
  const t = getT(lang);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [lastFailedPrompt, setLastFailedPrompt] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed || loading) return;

    setLastFailedPrompt(null);
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          language: lang,
          history: messages
            .filter((m) => !m.error)
            .map((m) => ({ role: m.role, text: m.text })),
          calculationContext: attachedContext
            ? {
                mode: attachedContext.mode,
                taxType: attachedContext.taxCode,
                taxName: lang === 'ar' ? attachedContext.taxNameAr : attachedContext.taxNameEn,
                rate: attachedContext.rate,
                amountHT: attachedContext.amountHT,
                taxAmount: attachedContext.taxAmount,
                amountTTC: attachedContext.amountTTC,
                transactionDate: attachedContext.transactionDate,
                effectiveDate: attachedContext.effectiveDate,
              }
            : null,
        }),
      });

      const data = (await response.json()) as { reply?: string; error?: string };

      if (!response.ok || !data.reply) {
        throw new Error(data.error || `HTTP ${response.status}`);
      }

      const aiMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        role: 'model',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      const errText = err instanceof Error ? err.message : 'Unknown error';
      setLastFailedPrompt(trimmed);
      setMessages((prev) => [
        ...prev,
        {
          id: `e-${Date.now()}`,
          role: 'model',
          text: `${t.assistant.errorPrefix} ${errText}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          error: true,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <div className="space-y-4 h-[calc(100vh-8.5rem)] flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-[#063B2C] dark:text-white">
            {t.assistant.title}
          </h2>
          <p className="text-sm text-slate-600 dark:text-emerald-200/75 mt-1">
            {t.assistant.subtitle}
          </p>
        </div>
        {messages.length > 0 && (
          <button
            type="button"
            onClick={() => {
              setMessages([]);
              setLastFailedPrompt(null);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22] self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t.actions.clearChat}</span>
          </button>
        )}
      </div>

      {attachedContext && (
        <div className="shrink-0 rounded-xl border border-[#E9D9A6] dark:border-[#524218] bg-[#FBF6E6] dark:bg-[#1E1A0B] px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 flex-wrap">
            <Calculator className="w-4 h-4 text-[#B3861D] dark:text-[#E5C158] shrink-0" />
            <span className="font-semibold text-[#5C440D] dark:text-[#FDE68A]">
              {t.assistant.attachedContext}:
            </span>
            <span className="font-mono-num text-[#063B2C] dark:text-emerald-100">
              {attachedContext.taxCode} ({attachedContext.rate}%) · HT:{' '}
              {formatDzd(attachedContext.amountHT, lang, currencyDisplay)} · Tax:{' '}
              {formatDzd(attachedContext.taxAmount, lang, currencyDisplay)} · TTC:{' '}
              {formatDzd(attachedContext.amountTTC, lang, currencyDisplay)}
            </span>
          </div>
          <button
            type="button"
            onClick={onClearContext}
            className="inline-flex items-center gap-1 text-slate-600 dark:text-emerald-200 hover:text-[#063B2C] dark:hover:text-white font-medium"
          >
            <X className="w-3.5 h-3.5" />
            <span>{t.assistant.removeContext}</span>
          </button>
        </div>
      )}

      <div className="flex-1 min-h-0 bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {messages.length === 0 ? (
            <div className="max-w-2xl mx-auto py-8 space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-xl bg-[#052E22] border border-[#D4AF37]/50 flex items-center justify-center mx-auto">
                  <Bot className="w-6 h-6 text-[#E5C158]" />
                </div>
                <h3 className="text-lg font-bold text-[#063B2C] dark:text-white">
                  {t.assistant.welcomeTitle}
                </h3>
                <p className="text-sm text-slate-600 dark:text-emerald-200/75 leading-relaxed">
                  {t.assistant.welcomeDesc}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {t.assistant.prompts.map((p, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => sendMessage(p)}
                    className="text-start p-3.5 rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] bg-[#F1F2EE] dark:bg-[#0E2B22] hover:border-emerald-600 dark:hover:border-[#E5C158] hover:bg-emerald-50/40 dark:hover:bg-[#12372C] transition-colors text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100 leading-relaxed"
                  >
                    {p}
                  </button>
                ))}
              </div>

              {attachedContext && (
                <div className="text-center">
                  <button
                    type="button"
                    onClick={() =>
                      sendMessage(
                        lang === 'ar'
                          ? 'اشرح لي نتيجة الحساب المرفقة خطوة بخطوة والمفاهيم الجبائية المرتبطة بها.'
                          : 'Please explain my attached tax calculation result step by step and the relevant Algerian accounting concepts.'
                      )
                    }
                    className="px-4 py-2.5 rounded-lg text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                  >
                    {lang === 'ar' ? 'اشرح الحساب المرفق الآن' : 'Explain Attached Calculation'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[88%] sm:max-w-[78%] rounded-xl px-4 py-3 text-sm ${
                    msg.role === 'user'
                      ? 'bg-[#052E22] text-white border border-[#D4AF37]/30'
                      : msg.error
                      ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
                      : 'bg-[#F1F2EE] dark:bg-[#0E2B22] border border-[#E0E3DD] dark:border-[#1B493C] text-[#063B2C] dark:text-emerald-50'
                  }`}
                >
                  {msg.error ? (
                    <div className="flex items-start gap-2.5">
                      <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                      <div className="space-y-2">
                        <p>{msg.text}</p>
                        {lastFailedPrompt && (
                          <button
                            type="button"
                            onClick={() => sendMessage(lastFailedPrompt)}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold underline"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>{t.assistant.retry}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ) : msg.role === 'user' ? (
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                  ) : (
                    <div className="space-y-1 text-sm">{renderFormattedText(msg.text)}</div>
                  )}
                  <div
                    className={`mt-1.5 text-[10px] font-mono-num ${
                      msg.role === 'user' ? 'text-emerald-200/75' : 'text-slate-500 dark:text-emerald-200/60'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            ))
          )}

          {loading && (
            <div className="flex justify-start">
              <div className="rounded-xl px-4 py-3 bg-[#F1F2EE] dark:bg-[#0E2B22] border border-[#E0E3DD] dark:border-[#1B493C] text-xs text-[#063B2C] dark:text-emerald-200 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
                <span>{t.assistant.thinking}</span>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-3 sm:p-4 border-t border-[#E3E6E0] dark:border-[#163D32] bg-[#FAF9F5] dark:bg-[#071D17] flex items-center gap-2.5 shrink-0"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t.assistant.placeholder}
            disabled={loading}
            className="flex-1 rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] px-3.5 py-2.5 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600 disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white transition-colors shrink-0"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">{t.actions.send}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
