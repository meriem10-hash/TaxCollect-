import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Calculator, FilePlus2, Sparkles, Info } from 'lucide-react';
import {
  CalculationMode,
  CalculatorSnapshot,
  Language,
  TaxRuleConfig,
} from '../types';
import { getT } from '../i18n/translations';
import { calculateTax, formatDzd } from '../utils/taxMath';

interface CalculatorViewProps {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  taxRules: TaxRuleConfig[];
  initialRuleId?: string | null;
  showLegalNotices: boolean;
  onSaveAsInvoice: (snapshot: CalculatorSnapshot) => void;
  onAskAi: (snapshot: CalculatorSnapshot) => void;
}

export const CalculatorView: React.FC<CalculatorViewProps> = ({
  lang,
  currencyDisplay,
  taxRules,
  initialRuleId,
  showLegalNotices,
  onSaveAsInvoice,
  onAskAi,
}) => {
  const t = getT(lang);
  const [mode, setMode] = useState<CalculationMode>('forward_ht');
  const [selectedRuleId, setSelectedRuleId] = useState<string>(
    initialRuleId || taxRules[0]?.id || 'tva-standard'
  );
  const [amountInput, setAmountInput] = useState<string>('100000');
  const [rateInput, setRateInput] = useState<string>(() => {
    const r = taxRules.find((x) => x.id === (initialRuleId || taxRules[0]?.id));
    return String(r?.defaultRate ?? 19);
  });
  const [transactionDate, setTransactionDate] = useState<string>(() =>
    new Date().toISOString().slice(0, 10)
  );

  useEffect(() => {
    if (initialRuleId) {
      const rule = taxRules.find((r) => r.id === initialRuleId);
      if (rule) {
        setSelectedRuleId(rule.id);
        setRateInput(String(rule.defaultRate));
      }
    }
  }, [initialRuleId, taxRules]);

  const activeRule = useMemo(
    () => taxRules.find((r) => r.id === selectedRuleId) || taxRules[0],
    [taxRules, selectedRuleId]
  );

  const handleRuleChange = (newRuleId: string) => {
    setSelectedRuleId(newRuleId);
    const rule = taxRules.find((r) => r.id === newRuleId);
    if (rule) {
      setRateInput(String(rule.defaultRate));
      if (rule.calculationNature === 'direct_profit_income' || rule.calculationNature === 'flat_turnover') {
        setMode('direct_base');
      } else {
        setMode('forward_ht');
      }
    }
  };

  const parsedAmount = Number(amountInput);
  const parsedRate = Number(rateInput);
  const isAmountValid = amountInput.trim() !== '' && Number.isFinite(parsedAmount) && parsedAmount >= 0;
  const isRateValid =
    rateInput.trim() !== '' && Number.isFinite(parsedRate) && parsedRate >= 0 && parsedRate <= 100;

  const result = useMemo(() => {
    return calculateTax(
      isAmountValid ? parsedAmount : 0,
      isRateValid ? parsedRate : 0,
      mode
    );
  }, [isAmountValid, parsedAmount, isRateValid, parsedRate, mode]);

  const datePrecedesEffective =
    Boolean(activeRule?.effectiveDate) &&
    Boolean(transactionDate) &&
    transactionDate < activeRule.effectiveDate;

  const buildSnapshot = (): CalculatorSnapshot => ({
    mode,
    taxRuleId: activeRule.id,
    taxCode: activeRule.code,
    taxNameEn: activeRule.nameEn,
    taxNameAr: activeRule.nameAr,
    rate: result.rate,
    amountHT: result.amountHT,
    taxAmount: result.taxAmount,
    amountTTC: result.amountTTC,
    transactionDate,
    effectiveDate: activeRule.effectiveDate,
  });

  const amountLabel =
    mode === 'reverse_ttc'
      ? t.calculator.amountLabelTtc
      : mode === 'direct_base'
      ? t.calculator.amountLabelBase
      : t.calculator.amountLabelHt;

  const rateDecimal = (result.rate / 100).toFixed(4).replace(/0+$/, '').replace(/\.$/, '');

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-[#063B2C] dark:text-white">
          {t.calculator.title}
        </h2>
        <p className="text-sm text-slate-600 dark:text-emerald-200/75 mt-1">
          {t.calculator.subtitle}
        </p>
      </div>

      {showLegalNotices && (
        <div className="rounded-xl border border-[#E9D9A6] dark:border-[#524218] bg-[#FBF6E6] dark:bg-[#1E1A0B] px-4 py-3 flex items-start gap-3 text-xs sm:text-sm text-[#5C440D] dark:text-[#FDE68A]">
          <Info className="w-4 h-4 text-[#B3861D] dark:text-[#E5C158] shrink-0 mt-0.5" />
          <p>{t.calculator.verificationBanner}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] p-5 sm:p-6 space-y-5">
          <div>
            <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-2">
              {t.calculator.modeLabel}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 p-1 bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-lg">
              {(['forward_ht', 'reverse_ttc', 'direct_base'] as CalculationMode[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMode(m)}
                  className={`px-2.5 py-2 rounded-md text-xs font-medium transition-colors text-center ${
                    mode === m
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-[#063B2C] dark:text-emerald-200 hover:bg-white/60 dark:hover:bg-white/5'
                  }`}
                >
                  {t.calculator.modes[m]}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label
              htmlFor="calc-amount"
              className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1.5"
            >
              {amountLabel}
            </label>
            <div className="relative">
              <input
                id="calc-amount"
                type="number"
                min="0"
                step="any"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3.5 py-2.5 pe-14 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
              <span className="absolute inset-y-0 end-3.5 flex items-center text-xs font-semibold text-[#B3861D] dark:text-[#E5C158] pointer-events-none">
                {lang === 'ar' ? 'د.ج' : 'DZD'}
              </span>
            </div>
            {!isAmountValid && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">
                {t.calculator.invalidAmount}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="calc-tax-type"
              className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1.5"
            >
              {t.calculator.taxTypeLabel}
            </label>
            <select
              id="calc-tax-type"
              value={selectedRuleId}
              onChange={(e) => handleRuleChange(e.target.value)}
              className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3.5 py-2.5 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              {taxRules.map((rule) => (
                <option key={rule.id} value={rule.id}>
                  {lang === 'ar' ? rule.nameAr : rule.nameEn}
                </option>
              ))}
            </select>
            {activeRule && (
              <p className="mt-1.5 text-[11px] text-slate-600 dark:text-emerald-200/70">
                {lang === 'ar' ? activeRule.legalReferenceAr : activeRule.legalReferenceEn}
              </p>
            )}
          </div>

          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="calc-rate"
                className="text-xs font-semibold text-[#063B2C] dark:text-emerald-100"
              >
                {t.calculator.rateLabel}
              </label>
              <span className="text-[11px] text-slate-500 dark:text-emerald-200/70">
                {t.calculator.presetRatesLabel}
              </span>
            </div>

            <div className="relative">
              <input
                id="calc-rate"
                type="number"
                min="0"
                max="100"
                step="0.1"
                value={rateInput}
                onChange={(e) => setRateInput(e.target.value)}
                placeholder={t.calculator.customRatePlaceholder}
                className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3.5 py-2.5 pe-10 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
              <span className="absolute inset-y-0 end-3.5 flex items-center text-xs font-semibold text-[#B3861D] dark:text-[#E5C158] pointer-events-none">
                %
              </span>
            </div>

            {!isRateValid && (
              <p className="text-xs text-rose-600 dark:text-rose-400">
                {t.calculator.invalidRate}
              </p>
            )}

            {activeRule && activeRule.rateOptions.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {activeRule.rateOptions.map((opt) => {
                  const selected = Number(rateInput) === opt.rate;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setRateInput(String(opt.rate))}
                      className={`px-2.5 py-1.5 rounded-md text-xs font-medium border transition-colors ${
                        selected
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-[#F1F2EE] dark:bg-[#0E2B22] text-[#063B2C] dark:text-emerald-100 border-[#DCE0D9] dark:border-[#1B493C] hover:border-emerald-600'
                      }`}
                    >
                      {lang === 'ar' ? opt.labelAr : opt.labelEn}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="calc-date"
                className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1.5"
              >
                {t.calculator.dateLabel}
              </label>
              <input
                id="calc-date"
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
                className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div>
              <span className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1.5">
                {t.calculator.effectiveDateLabel}
              </span>
              <div className="rounded-lg border border-[#E0E3DD] dark:border-[#1B493C] bg-[#F1F2EE] dark:bg-[#0E2B22] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-emerald-100">
                {activeRule?.effectiveDate || '—'}
              </div>
            </div>
          </div>

          {datePrecedesEffective && (
            <div className="rounded-lg border border-amber-300 dark:border-amber-700/60 bg-amber-50 dark:bg-amber-950/30 p-3 flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <p>{t.calculator.dateWarning}</p>
            </div>
          )}
        </div>

        <div className="lg:col-span-7 space-y-6">
          {/* Primary Results Card: Dark Emerald with Soft Gold Highlights */}
          <div className="bg-[#052E22] text-white rounded-xl p-5 sm:p-6 border border-[#D4AF37]/40">
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <Calculator className="w-5 h-5 text-[#E5C158]" />
                <h3 className="text-base font-semibold">{t.calculator.resultsTitle}</h3>
              </div>
              <span className="text-xs font-mono-num text-[#FDE68A]">
                {activeRule?.code} · {result.rate}%
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 py-5">
              <div>
                <div className="text-xs text-emerald-200/80">{t.calculator.resAmountHt}</div>
                <div className="mt-1.5 text-xl sm:text-2xl font-bold font-mono-num text-white">
                  {formatDzd(result.amountHT, lang, currencyDisplay)}
                </div>
              </div>

              <div>
                <div className="text-xs text-emerald-200/80">{t.calculator.resTaxAmount}</div>
                <div className="mt-1.5 text-xl sm:text-2xl font-bold font-mono-num text-[#FDE68A]">
                  {formatDzd(result.taxAmount, lang, currencyDisplay)}
                </div>
              </div>

              <div>
                <div className="text-xs text-emerald-200/80">
                  {mode === 'direct_base' ? t.calculator.resNetAfterTax : t.calculator.resAmountTtc}
                </div>
                <div className="mt-1.5 text-xl sm:text-2xl font-bold font-mono-num text-white">
                  {formatDzd(
                    mode === 'direct_base' ? result.netAfterTax : result.amountTTC,
                    lang,
                    currencyDisplay
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center gap-3">
              <button
                type="button"
                disabled={!isAmountValid || !isRateValid || result.amountHT <= 0}
                onClick={() => onSaveAsInvoice(buildSnapshot())}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white transition-colors"
              >
                <FilePlus2 className="w-4 h-4" />
                <span>{t.actions.saveAsInvoice}</span>
              </button>

              <button
                type="button"
                disabled={!isAmountValid || !isRateValid}
                onClick={() => onAskAi(buildSnapshot())}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-medium bg-white/10 hover:bg-white/15 text-white border border-[#D4AF37]/40 transition-colors"
              >
                <Sparkles className="w-4 h-4 text-[#E5C158]" />
                <span>{t.actions.askAi}</span>
              </button>
            </div>
          </div>

          {/* Formula Breakdown Card */}
          <div className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] p-5 sm:p-6 space-y-4">
            <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
              {t.calculator.formulaTitle}
            </h3>

            <div className="space-y-4 text-sm">
              <div className="p-4 rounded-lg bg-[#F1F2EE] dark:bg-[#0E2B22] border border-[#E0E3DD] dark:border-[#1B493C]">
                <div className="text-xs font-semibold text-emerald-800 dark:text-[#E5C158] mb-1">
                  {t.calculator.step1}
                </div>
                <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                  {mode === 'reverse_ttc'
                    ? `TTC = ${formatDzd(result.amountTTC, lang, currencyDisplay)}  |  r = ${result.rate}% = ${rateDecimal}`
                    : `Base (HT) = ${formatDzd(result.amountHT, lang, currencyDisplay)}  |  r = ${result.rate}% = ${rateDecimal}`}
                </p>
              </div>

              <div className="p-4 rounded-lg bg-[#F1F2EE] dark:bg-[#0E2B22] border border-[#E0E3DD] dark:border-[#1B493C] space-y-1.5">
                <div className="text-xs font-semibold text-emerald-800 dark:text-[#E5C158]">
                  {t.calculator.step2}
                </div>
                {mode === 'reverse_ttc' ? (
                  <>
                    <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                      HT = TTC ÷ (1 + r) = {result.amountTTC.toFixed(2)} ÷ (1 + {rateDecimal}) ={' '}
                      <strong>{formatDzd(result.amountHT, lang, currencyDisplay)}</strong>
                    </p>
                    <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                      Tax = TTC − HT = {result.amountTTC.toFixed(2)} − {result.amountHT.toFixed(2)} ={' '}
                      <strong>{formatDzd(result.taxAmount, lang, currencyDisplay)}</strong>
                    </p>
                  </>
                ) : mode === 'direct_base' ? (
                  <>
                    <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                      Tax = Base × r = {result.amountHT.toFixed(2)} × {rateDecimal} ={' '}
                      <strong>{formatDzd(result.taxAmount, lang, currencyDisplay)}</strong>
                    </p>
                    <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                      Net = Base − Tax = {result.amountHT.toFixed(2)} − {result.taxAmount.toFixed(2)} ={' '}
                      <strong>{formatDzd(result.netAfterTax, lang, currencyDisplay)}</strong>
                    </p>
                  </>
                ) : (
                  <>
                    <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                      Tax = HT × r = {result.amountHT.toFixed(2)} × {rateDecimal} ={' '}
                      <strong>{formatDzd(result.taxAmount, lang, currencyDisplay)}</strong>
                    </p>
                    <p className="font-mono-num text-xs sm:text-sm text-[#063B2C] dark:text-emerald-100">
                      TTC = HT + Tax = {result.amountHT.toFixed(2)} + {result.taxAmount.toFixed(2)} ={' '}
                      <strong>{formatDzd(result.amountTTC, lang, currencyDisplay)}</strong>
                    </p>
                  </>
                )}
              </div>

              <div className="p-4 rounded-lg bg-[#FBF6E6] dark:bg-[#1E1A0B] border border-[#E9D9A6] dark:border-[#524218]">
                <div className="text-xs font-semibold text-[#8C6610] dark:text-[#E5C158] mb-1">
                  {t.calculator.step3}
                </div>
                <p className="text-xs sm:text-sm text-[#4B390D] dark:text-emerald-100 leading-relaxed">
                  {activeRule ? (lang === 'ar' ? activeRule.verificationNoteAr : activeRule.verificationNoteEn) : ''}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
