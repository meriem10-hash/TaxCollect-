import React, { useState } from 'react';
import {
  LayoutDashboard,
  Calculator,
  FileText,
  BarChart3,
  Bot,
  BookOpen,
  Settings,
  Languages,
  Sun,
  Moon,
  Plus,
  Menu,
  X,
} from 'lucide-react';
import { Language, NavView, Theme } from '../types';
import { getT } from '../i18n/translations';
import { TaxCollectLogo } from './TaxCollectLogo';

interface LayoutProps {
  lang: Language;
  theme: Theme;
  activeView: NavView;
  onSelectView: (view: NavView) => void;
  onToggleLanguage: () => void;
  onToggleTheme: () => void;
  onNewInvoice: () => void;
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({
  lang,
  theme,
  activeView,
  onSelectView,
  onToggleLanguage,
  onToggleTheme,
  onNewInvoice,
  children,
}) => {
  const t = getT(lang);
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems: Array<{ id: NavView; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'dashboard', label: t.nav.dashboard, icon: LayoutDashboard },
    { id: 'calculator', label: t.nav.calculator, icon: Calculator },
    { id: 'invoices', label: t.nav.invoices, icon: FileText },
    { id: 'reports', label: t.nav.reports, icon: BarChart3 },
    { id: 'assistant', label: t.nav.assistant, icon: Bot },
    { id: 'library', label: t.nav.library, icon: BookOpen },
    { id: 'settings', label: t.nav.settings, icon: Settings },
  ];

  const activeTitle = navItems.find((n) => n.id === activeView)?.label || t.nav.dashboard;

  const handleNavClick = (id: NavView) => {
    onSelectView(id);
    setMobileOpen(false);
  };

  return (
    <div className="min-h-screen flex bg-[#FAF9F5] text-[#063B2C] dark:bg-[#051410] dark:text-emerald-50">
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-[#03120D]/60 backdrop-blur-xs lg:hidden no-print"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar: Deep Dark Emerald with Soft Gold Highlights */}
      <aside
        className={`fixed inset-y-0 start-0 z-50 w-[264px] bg-[#052E22] text-emerald-50 flex flex-col border-e border-[#0E4A38] transition-transform duration-200 ease-out lg:static lg:translate-x-0 no-print ${
          mobileOpen
            ? 'translate-x-0'
            : lang === 'ar'
            ? 'translate-x-full lg:translate-x-0'
            : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-5 flex items-center justify-between border-b border-white/10 shrink-0">
          <button
            type="button"
            onClick={() => handleNavClick('dashboard')}
            className="flex items-center gap-3 text-start focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E5C158] rounded-lg py-1"
          >
            <TaxCollectLogo className="w-9 h-9 shrink-0 shadow-xs" />
            <div className="min-w-0">
              <span className="block text-base font-bold tracking-tight text-white whitespace-nowrap">
                {t.brand}
              </span>
              <span className="block text-[11px] text-emerald-200/75 truncate">
                {t.brandSubtitle}
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1.5 text-emerald-200 hover:text-white rounded-md"
            aria-label={t.actions.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto" aria-label="Main Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors duration-150 whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600/30 text-white border border-[#D4AF37]/45 shadow-xs'
                    : 'text-emerald-100/80 hover:bg-white/8 hover:text-white border border-transparent'
                }`}
              >
                <Icon
                  className={`w-[18px] h-[18px] shrink-0 ${
                    isActive ? 'text-[#E5C158]' : 'text-emerald-300/75'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-white/10 space-y-2 shrink-0">
          <div className="text-xs text-emerald-200/80 flex items-center justify-between px-1">
            <span>{lang === 'ar' ? 'العملة الافتراضية' : 'Base Currency'}</span>
            <span className="font-mono-num font-semibold text-[#E5C158]">DZD · د.ج</span>
          </div>
          <p className="text-[11px] text-emerald-200/70 leading-relaxed px-1">
            {lang === 'ar'
              ? 'مصمم للنظام الجبائي الجزائري · يرجى التحقق من قانون المالية الساري.'
              : 'Built for Algerian Taxation · Verify rates with active Finance Law.'}
          </p>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar Contract: Context Breadcrumb | Utility Controls | Primary CTA */}
        <header className="sticky top-0 z-30 h-16 bg-[#FCFBF8]/95 dark:bg-[#071D17]/95 backdrop-blur-sm border-b border-[#E3E6E0] dark:border-[#153D31] px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 -ms-2 rounded-lg text-[#063B2C] dark:text-emerald-200 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22]"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="font-bold text-[#063B2C] dark:text-white whitespace-nowrap hidden sm:inline">
                {t.brand}
              </span>
              <span className="text-[#C89B2B] dark:text-[#E5C158] hidden sm:inline" aria-hidden="true">
                /
              </span>
              <h1 className="font-semibold text-[#0A4A37] dark:text-emerald-100 truncate">
                {activeTitle}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onToggleLanguage}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22] transition-colors whitespace-nowrap shrink-0"
              title={lang === 'en' ? 'Switch to Arabic (RTL)' : 'التبديل إلى الإنجليزية'}
            >
              <Languages className="w-4 h-4 text-emerald-600 dark:text-[#E5C158] shrink-0" />
              <span>{t.actions.switchLang}</span>
            </button>

            <button
              type="button"
              onClick={onToggleTheme}
              className="p-2 rounded-lg border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-200 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22] transition-colors shrink-0"
              aria-label={theme === 'light' ? t.settings.darkMode : t.settings.lightMode}
              title={theme === 'light' ? t.settings.darkMode : t.settings.lightMode}
            >
              {theme === 'light' ? (
                <Moon className="w-4 h-4" />
              ) : (
                <Sun className="w-4 h-4 text-[#E5C158]" />
              )}
            </button>

            <button
              type="button"
              onClick={onNewInvoice}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>{t.actions.newInvoice}</span>
            </button>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
