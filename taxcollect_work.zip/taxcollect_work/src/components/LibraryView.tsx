import React, { useMemo, useState } from 'react';
import { Search, AlertTriangle, Calculator, BookOpen } from 'lucide-react';
import { TAX_LIBRARY_ARTICLES } from '../data/taxRules';
import { Language, TaxRuleConfig } from '../types';
import { getT } from '../i18n/translations';

interface LibraryViewProps {
  lang: Language;
  taxRules: TaxRuleConfig[];
  onOpenInCalculator: (ruleId: string) => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  lang,
  taxRules,
  onOpenInCalculator,
}) => {
  const t = getT(lang);
  const [search, setSearch] = useState('');
  const [activeCode, setActiveCode] = useState<string>('ALL');

  const combinedItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return TAX_LIBRARY_ARTICLES.map((article) => {
      const rule = taxRules.find((r) => r.id === article.ruleId);
      return { article, rule };
    }).filter(({ article, rule }) => {
      if (!rule) return false;
      if (activeCode !== 'ALL' && rule.code !== activeCode) return false;
      if (!q) return true;
      return (
        rule.code.toLowerCase().includes(q) ||
        rule.nameEn.toLowerCase().includes(q) ||
        rule.nameAr.toLowerCase().includes(q) ||
        article.summaryEn.toLowerCase().includes(q) ||
        article.summaryAr.toLowerCase().includes(q)
      );
    });
  }, [search, activeCode, taxRules]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-[#063B2C] dark:text-white">
          {t.library.title}
        </h2>
        <p className="text-sm text-[#4B635B] dark:text-emerald-200/70 mt-1">
          {t.library.subtitle}
        </p>
      </div>

      {/* Search & Tax Category Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#6B7F78] dark:text-emerald-200/50 absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.library.searchPlaceholder}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] ps-10 pe-3.5 py-2 text-sm text-[#063B2C] dark:text-white placeholder:text-[#6B7F78] focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {['ALL', 'TVA', 'IBS', 'IRG', 'IFU', 'TAP', 'CUSTOM'].map((code) => (
            <button
              key={code}
              type="button"
              onClick={() => setActiveCode(code)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeCode === code
                  ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-[#0A221B] text-[#4B635B] dark:text-emerald-200/80 border border-[#E0E3DD] dark:border-[#1B493C] hover:text-[#063B2C] dark:hover:text-white'
              }`}
            >
              {code === 'ALL' ? t.library.allCategories : code}
            </button>
          ))}
        </div>
      </div>

      {/* Articles Grid */}
      {combinedItems.length === 0 ? (
        <div className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] p-10 text-center">
          <BookOpen className="w-8 h-8 text-[#B3861D] dark:text-[#E5C158] mx-auto mb-2" />
          <p className="text-sm text-[#4B635B] dark:text-emerald-200/70">{t.invoices.emptyTitle}</p>
        </div>
      ) : (
        <div className="space-y-6">
          {combinedItems.map(({ article, rule }) => {
            if (!rule) return null;
            return (
              <article
                key={rule.id}
                className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden shadow-xs"
              >
                {/* Article Header */}
                <div className="px-5 sm:px-6 py-4 border-b border-[#E3E6E0] dark:border-[#163D32] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#F1F2EE]/70 dark:bg-[#0E2B22]/70">
                  <div>
                    <div className="text-xs text-[#4B635B] dark:text-emerald-200/70 flex items-center gap-2 flex-wrap">
                      <span>{lang === 'ar' ? article.categoryAr : article.categoryEn}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num">
                        {t.library.effectiveSince}: {rule.effectiveDate}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num font-semibold text-[#B3861D] dark:text-[#E5C158]">
                        {t.library.configuredRate}: {rule.defaultRate}%
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-[#063B2C] dark:text-white mt-1">
                      {lang === 'ar' ? rule.nameAr : rule.nameEn}
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenInCalculator(rule.id)}
                    className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white self-start sm:self-auto whitespace-nowrap shadow-xs transition-colors"
                  >
                    <Calculator className="w-3.5 h-3.5 text-[#FDE68A]" />
                    <span>{t.library.configureInCalc}</span>
                  </button>
                </div>

                {/* Body */}
                <div className="p-5 sm:p-6 space-y-5">
                  <p className="text-sm text-[#1E4538] dark:text-emerald-100/90 leading-relaxed">
                    {lang === 'ar' ? article.summaryAr : article.summaryEn}
                  </p>

                  {/* Legal Verification Notice */}
                  <div className="rounded-lg border border-[#E9D9A6] dark:border-[#D4AF37]/30 bg-[#FBF6E6] dark:bg-[#1E1A0B]/70 p-3.5 flex items-start gap-2.5 text-xs text-[#6B4F0E] dark:text-[#FDE68A]">
                    <AlertTriangle className="w-4 h-4 text-[#B3861D] dark:text-[#E5C158] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold">{t.library.verificationRequired}: </span>
                      <span>
                        {lang === 'ar' ? rule.verificationNoteAr : rule.verificationNoteEn}
                      </span>
                      <div className="mt-1 text-[11px] opacity-85">
                        {t.library.legalBasis}:{' '}
                        {lang === 'ar' ? rule.legalReferenceAr : rule.legalReferenceEn}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                    {/* Scope & Formula */}
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-xs font-semibold text-[#4B635B] dark:text-emerald-200/70 mb-1">
                          {t.library.scopeTitle}
                        </h4>
                        <p className="text-sm text-[#1E4538] dark:text-emerald-100/80 leading-relaxed">
                          {lang === 'ar' ? article.scopeAr : article.scopeEn}
                        </p>
                      </div>

                      <div>
                        <h4 className="text-xs font-semibold text-[#4B635B] dark:text-emerald-200/70 mb-1.5">
                          {t.library.formulaTitle}
                        </h4>
                        <div className="rounded-lg bg-[#052E22] border border-[#D4AF37]/30 text-[#FDE68A] px-3.5 py-2.5 font-mono-num text-xs overflow-x-auto">
                          {lang === 'ar' ? article.formulaAr : article.formulaEn}
                        </div>
                      </div>

                      <div>
                        <h4 className="text-xs font-semibold text-[#4B635B] dark:text-emerald-200/70 mb-1.5">
                          {t.library.applicableRates}
                        </h4>
                        <ul className="space-y-1 text-xs text-[#1E4538] dark:text-emerald-100/80">
                          {rule.rateOptions.map((opt) => (
                            <li key={opt.id} className="font-mono-num">
                              · {lang === 'ar' ? opt.labelAr : opt.labelEn}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Worked Example & Notes */}
                    <div className="space-y-4">
                      <div className="rounded-lg bg-[#F1F2EE] dark:bg-[#0E2B22] border border-[#E0E3DD] dark:border-[#1B493C] p-4">
                        <h4 className="text-xs font-semibold text-emerald-700 dark:text-[#E5C158] mb-2">
                          {t.library.exampleTitle} —{' '}
                          {lang === 'ar' ? article.exampleTitleAr : article.exampleTitleEn}
                        </h4>
                        <ul className="space-y-1.5 text-xs sm:text-sm font-mono-num text-[#063B2C] dark:text-emerald-50">
                          {(lang === 'ar' ? article.exampleStepsAr : article.exampleStepsEn).map(
                            (step, idx) => (
                              <li key={idx}>{step}</li>
                            )
                          )}
                        </ul>
                      </div>

                      <div>
                        <h4 className="text-xs font-semibold text-[#4B635B] dark:text-emerald-200/70 mb-1.5">
                          {t.library.notesTitle}
                        </h4>
                        <ul className="space-y-1.5 text-xs text-[#4B635B] dark:text-emerald-200/80 leading-relaxed">
                          {(lang === 'ar' ? article.keyNotesAr : article.keyNotesEn).map((note, idx) => (
                            <li key={idx}>· {note}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
