import React, { useState } from 'react';
import { RotateCcw, Download, Trash2, Check, FolderArchive } from 'lucide-react';
import {
  Invoice,
  Language,
  TaxRuleConfig,
  UserPreferences,
} from '../types';
import { getT } from '../i18n/translations';

interface SettingsViewProps {
  preferences: UserPreferences;
  taxRules: TaxRuleConfig[];
  invoices: Invoice[];
  onUpdatePreferences: (patch: Partial<UserPreferences>) => void;
  onUpdateTaxRule: (ruleId: string, patch: Partial<TaxRuleConfig>) => void;
  onRestoreDefaultRules: () => void;
  onResetSampleInvoices: () => void;
  onClearAllInvoices: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  preferences,
  taxRules,
  invoices,
  onUpdatePreferences,
  onUpdateTaxRule,
  onRestoreDefaultRules,
  onResetSampleInvoices,
  onClearAllInvoices,
}) => {
  const lang: Language = preferences.language;
  const t = getT(lang);
  const [confirmClear, setConfirmClear] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipError, setZipError] = useState('');

  const handleDownloadProjectZip = async () => {
    setDownloadingZip(true);
    setZipError('');
    try {
      const response = await fetch('/api/export-project');
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `TaxCollect_Project_${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      setZipError(err instanceof Error ? err.message : 'Download failed');
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleExportJson = () => {
    const payload = {
      app: 'TaxCollect',
      exportedAt: new Date().toISOString(),
      preferences,
      taxRules,
      invoices,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TaxCollect_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-[#063B2C] dark:text-white">
          {t.settings.title}
        </h2>
        <p className="text-sm text-[#4B635B] dark:text-emerald-200/70 mt-1">
          {t.settings.subtitle}
        </p>
      </div>

      {/* Language, Theme & Currency */}
      <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] p-5 sm:p-6 space-y-6">
        <h3 className="text-base font-semibold text-[#063B2C] dark:text-white">
          {t.settings.appearanceTitle}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Language */}
          <div>
            <label className="block text-xs font-semibold text-[#4B635B] dark:text-emerald-200/80 mb-2">
              {t.settings.languageLabel}
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-lg border border-[#E0E3DD] dark:border-[#1B493C]">
              <button
                type="button"
                onClick={() => onUpdatePreferences({ language: 'en' })}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                  preferences.language === 'en'
                    ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                    : 'text-[#4B635B] dark:text-emerald-200/75 hover:text-[#063B2C] dark:hover:text-white'
                }`}
              >
                English (LTR)
              </button>
              <button
                type="button"
                onClick={() => onUpdatePreferences({ language: 'ar' })}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                  preferences.language === 'ar'
                    ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                    : 'text-[#4B635B] dark:text-emerald-200/75 hover:text-[#063B2C] dark:hover:text-white'
                }`}
              >
                العربية (RTL)
              </button>
            </div>
            <p className="text-[11px] text-[#6B7F78] dark:text-emerald-200/60 mt-2">
              {t.settings.languageDesc}
            </p>
          </div>

          {/* Theme */}
          <div>
            <label className="block text-xs font-semibold text-[#4B635B] dark:text-emerald-200/80 mb-2">
              {t.settings.themeLabel}
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-lg border border-[#E0E3DD] dark:border-[#1B493C]">
              <button
                type="button"
                onClick={() => onUpdatePreferences({ theme: 'light' })}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                  preferences.theme === 'light'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-[#4B635B] dark:text-emerald-200/75 hover:text-[#063B2C] dark:hover:text-white'
                }`}
              >
                {t.settings.lightMode}
              </button>
              <button
                type="button"
                onClick={() => onUpdatePreferences({ theme: 'dark' })}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                  preferences.theme === 'dark'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-[#4B635B] dark:text-emerald-200/75 hover:text-[#063B2C] dark:hover:text-white'
                }`}
              >
                {t.settings.darkMode}
              </button>
            </div>
          </div>

          {/* Currency Display */}
          <div>
            <label className="block text-xs font-semibold text-[#4B635B] dark:text-emerald-200/80 mb-2">
              {t.settings.currencyLabel}
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-lg border border-[#E0E3DD] dark:border-[#1B493C]">
              <button
                type="button"
                onClick={() => onUpdatePreferences({ currencyDisplay: 'code' })}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                  preferences.currencyDisplay === 'code'
                    ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                    : 'text-[#4B635B] dark:text-emerald-200/75 hover:text-[#063B2C] dark:hover:text-white'
                }`}
              >
                DZD
              </button>
              <button
                type="button"
                onClick={() => onUpdatePreferences({ currencyDisplay: 'symbol' })}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                  preferences.currencyDisplay === 'symbol'
                    ? 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                    : 'text-[#4B635B] dark:text-emerald-200/75 hover:text-[#063B2C] dark:hover:text-white'
                }`}
              >
                {lang === 'ar' ? 'د.ج' : 'DA'}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Organization / Student Project Profile */}
      <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] p-5 sm:p-6 space-y-4">
        <h3 className="text-base font-semibold text-[#063B2C] dark:text-white">
          {t.settings.entityTitle}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-[#4B635B] dark:text-emerald-200/80 mb-1.5">
              {t.settings.entityNameLabel}
            </label>
            <input
              type="text"
              value={preferences.entityName}
              onChange={(e) => onUpdatePreferences({ entityName: e.target.value })}
              className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3.5 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#4B635B] dark:text-emerald-200/80 mb-1.5">
              {t.settings.entityNifLabel}
            </label>
            <input
              type="text"
              value={preferences.entityNif}
              onChange={(e) => onUpdatePreferences({ entityNif: e.target.value })}
              placeholder="001616098451234"
              className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3.5 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>
        </div>

        <label className="flex items-start gap-3 pt-2 cursor-pointer">
          <input
            type="checkbox"
            checked={preferences.showLegalNotices}
            onChange={(e) => onUpdatePreferences({ showLegalNotices: e.target.checked })}
            className="mt-1 w-4 h-4 rounded border-[#D4D9D2] text-emerald-600 focus:ring-emerald-600"
          />
          <div>
            <span className="block text-sm font-medium text-[#063B2C] dark:text-emerald-50">
              {t.settings.showNoticesLabel}
            </span>
            <span className="block text-xs text-[#6B7F78] dark:text-emerald-200/60">
              {t.settings.showNoticesDesc}
            </span>
          </div>
        </label>
      </section>

      {/* Configurable Tax Rules & Effective Dates */}
      <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden">
        <div className="px-5 sm:px-6 py-4 border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/70 dark:bg-[#0E2B22]/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-[#063B2C] dark:text-white">
              {t.settings.rulesTitle}
            </h3>
            <p className="text-xs text-[#4B635B] dark:text-emerald-200/70 mt-0.5">
              {t.settings.rulesDesc}
            </p>
          </div>
          <button
            type="button"
            onClick={onRestoreDefaultRules}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#FAF9F5] dark:hover:bg-[#14392E] self-start sm:self-auto whitespace-nowrap transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#B3861D] dark:text-[#E5C158]" />
            <span>{t.actions.restoreDefaults}</span>
          </button>
        </div>

        <div className="divide-y divide-[#ECEEE9] dark:divide-[#163D32]">
          {taxRules.map((rule) => (
            <div
              key={rule.id}
              className="p-4 sm:px-6 grid grid-cols-1 md:grid-cols-12 gap-4 items-center"
            >
              <div className="md:col-span-5">
                <div className="text-sm font-semibold text-[#063B2C] dark:text-white">
                  {lang === 'ar' ? rule.nameAr : rule.nameEn}
                </div>
                <div className="text-xs text-[#6B7F78] dark:text-emerald-200/60 mt-0.5">
                  {lang === 'ar' ? rule.legalReferenceAr : rule.legalReferenceEn}
                </div>
              </div>

              <div className="md:col-span-3">
                <label className="block text-[11px] font-medium text-[#4B635B] dark:text-emerald-200/70 mb-1">
                  {t.settings.ruleRate}
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={rule.defaultRate}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    if (Number.isFinite(val) && val >= 0 && val <= 100) {
                      onUpdateTaxRule(rule.id, { defaultRate: val, isUserModified: true });
                    }
                  }}
                  className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-1.5 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="md:col-span-4">
                <label className="block text-[11px] font-medium text-[#4B635B] dark:text-emerald-200/70 mb-1">
                  {t.settings.ruleEffectiveDate}
                </label>
                <input
                  type="date"
                  value={rule.effectiveDate}
                  onChange={(e) =>
                    onUpdateTaxRule(rule.id, {
                      effectiveDate: e.target.value,
                      isUserModified: true,
                    })
                  }
                  className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-1.5 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Data Persistence & Backup */}
      <section className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-[#063B2C] dark:text-white">
              {t.settings.dataTitle}
            </h3>
            <p className="text-xs text-[#4B635B] dark:text-emerald-200/70 mt-0.5">
              {t.settings.dataDesc}
            </p>
          </div>
          <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-[#E5C158]">
            <Check className="w-3.5 h-3.5" />
            <span>{t.settings.savedToast}</span>
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            type="button"
            disabled={downloadingZip}
            onClick={handleDownloadProjectZip}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white shadow-xs transition-colors"
          >
            <FolderArchive className="w-4 h-4 text-[#FDE68A]" />
            <span>{downloadingZip ? t.settings.exportingZip : t.settings.exportProjectZip}</span>
          </button>

          <button
            type="button"
            onClick={handleExportJson}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-medium border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#FAF9F5] dark:hover:bg-[#14392E] transition-colors"
          >
            <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t.settings.exportJson}</span>
          </button>

          <button
            type="button"
            onClick={onResetSampleInvoices}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-medium border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#FAF9F5] dark:hover:bg-[#14392E] transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-[#B3861D] dark:text-[#E5C158]" />
            <span>{t.settings.resetSampleData}</span>
          </button>

          {!confirmClear ? (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-medium border border-rose-200 dark:border-rose-900 bg-white dark:bg-[#0A221B] text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t.settings.clearAllInvoices}</span>
            </button>
          ) : (
            <div className="inline-flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onClearAllInvoices();
                  setConfirmClear(false);
                }}
                className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-rose-600 text-white hover:bg-rose-500"
              >
                {t.actions.confirmDelete}
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="px-3 py-2 rounded-lg text-xs font-medium border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100"
              >
                {t.actions.cancel}
              </button>
            </div>
          )}
        </div>
        {zipError && (
          <p className="text-xs text-rose-600 dark:text-rose-400">{zipError}</p>
        )}
      </section>
    </div>
  );
};
