import React, { useMemo, useState } from 'react';
import { Search, Plus, Pencil, Trash2, Eye, X, FileText } from 'lucide-react';
import {
  Invoice,
  InvoiceStatus,
  Language,
  TaxRuleConfig,
} from '../types';
import { getT } from '../i18n/translations';
import { calculateTax, formatDzd } from '../utils/taxMath';

interface InvoicesViewProps {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  invoices: Invoice[];
  taxRules: TaxRuleConfig[];
  onAddInvoice: (invoice: Omit<Invoice, 'id' | 'createdAt'>) => void;
  onUpdateInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
  prefillModalOpen: boolean;
  prefillData?: Partial<Omit<Invoice, 'id' | 'createdAt'>> | null;
  onCloseExternalModal: () => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  lang,
  currencyDisplay,
  invoices,
  taxRules,
  onAddInvoice,
  onUpdateInvoice,
  onDeleteInvoice,
  prefillModalOpen,
  prefillData,
  onCloseExternalModal,
}) => {
  const t = getT(lang);
  const [search, setSearch] = useState('');
  const [taxFilter, setTaxFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest'>('newest');

  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isLocalAddOpen, setIsLocalAddOpen] = useState(false);

  const isModalOpen = isLocalAddOpen || prefillModalOpen || editingInvoice !== null;

  const generateNextNumber = () => {
    const num = invoices.length + 1;
    return `FAC-${new Date().getFullYear()}-${String(num).padStart(3, '0')}`;
  };

  const [formNumber, setFormNumber] = useState('');
  const [formClient, setFormClient] = useState('');
  const [formNif, setFormNif] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formDate, setFormDate] = useState(new Date().toISOString().slice(0, 10));
  const [formRuleId, setFormRuleId] = useState(taxRules[0]?.id || 'tva-standard');
  const [formRate, setFormRate] = useState(String(taxRules[0]?.defaultRate ?? 19));
  const [formAmountHt, setFormAmountHt] = useState('');
  const [formStatus, setFormStatus] = useState<InvoiceStatus>('pending');
  const [formNotes, setFormNotes] = useState('');
  const [formError, setFormError] = useState('');

  React.useEffect(() => {
    if (editingInvoice) {
      setFormNumber(editingInvoice.invoiceNumber);
      setFormClient(editingInvoice.clientName);
      setFormNif(editingInvoice.clientNif || '');
      setFormDescription(editingInvoice.description);
      setFormDate(editingInvoice.date);
      setFormRuleId(editingInvoice.taxRuleId);
      setFormRate(String(editingInvoice.taxRate));
      setFormAmountHt(String(editingInvoice.amountHT));
      setFormStatus(editingInvoice.status);
      setFormNotes(editingInvoice.notes || '');
      setFormError('');
    } else if (prefillModalOpen) {
      setFormNumber(generateNextNumber());
      setFormClient(prefillData?.clientName || '');
      setFormNif(prefillData?.clientNif || '');
      setFormDescription(prefillData?.description || '');
      setFormDate(prefillData?.date || new Date().toISOString().slice(0, 10));
      const rId = prefillData?.taxRuleId || taxRules[0]?.id || 'tva-standard';
      setFormRuleId(rId);
      const foundRule = taxRules.find((r) => r.id === rId);
      setFormRate(String(prefillData?.taxRate ?? foundRule?.defaultRate ?? 19));
      setFormAmountHt(prefillData?.amountHT ? String(prefillData.amountHT) : '');
      setFormStatus(prefillData?.status || 'pending');
      setFormNotes(prefillData?.notes || '');
      setFormError('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingInvoice, prefillModalOpen, prefillData]);

  const openNewModal = () => {
    setEditingInvoice(null);
    setFormNumber(generateNextNumber());
    setFormClient('');
    setFormNif('');
    setFormDescription('');
    setFormDate(new Date().toISOString().slice(0, 10));
    const defaultRule = taxRules[0];
    setFormRuleId(defaultRule?.id || 'tva-standard');
    setFormRate(String(defaultRule?.defaultRate ?? 19));
    setFormAmountHt('');
    setFormStatus('pending');
    setFormNotes('');
    setFormError('');
    setIsLocalAddOpen(true);
  };

  const closeModal = () => {
    setIsLocalAddOpen(false);
    setEditingInvoice(null);
    onCloseExternalModal();
  };

  const handleRuleSelect = (ruleId: string) => {
    setFormRuleId(ruleId);
    const found = taxRules.find((r) => r.id === ruleId);
    if (found) {
      setFormRate(String(found.defaultRate));
    }
  };

  const liveCalc = useMemo(() => {
    const ht = Number(formAmountHt);
    const rate = Number(formRate);
    return calculateTax(
      Number.isFinite(ht) && ht >= 0 ? ht : 0,
      Number.isFinite(rate) && rate >= 0 ? rate : 0,
      'forward_ht'
    );
  }, [formAmountHt, formRate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ht = Number(formAmountHt);
    const rate = Number(formRate);

    if (
      !formNumber.trim() ||
      !formClient.trim() ||
      !formDescription.trim() ||
      !Number.isFinite(ht) ||
      ht <= 0 ||
      !Number.isFinite(rate) ||
      rate < 0 ||
      rate > 100
    ) {
      setFormError(t.invoices.validationRequired);
      return;
    }

    const rule = taxRules.find((r) => r.id === formRuleId) || taxRules[0];
    const calc = calculateTax(ht, rate, 'forward_ht');

    const payload: Omit<Invoice, 'id' | 'createdAt'> = {
      invoiceNumber: formNumber.trim(),
      clientName: formClient.trim(),
      clientNif: formNif.trim() || undefined,
      description: formDescription.trim(),
      date: formDate,
      taxRuleId: rule.id,
      taxCode: rule.code,
      taxRate: calc.rate,
      amountHT: calc.amountHT,
      taxAmount: calc.taxAmount,
      amountTTC: calc.amountTTC,
      status: formStatus,
      notes: formNotes.trim() || undefined,
    };

    if (editingInvoice) {
      onUpdateInvoice({
        ...editingInvoice,
        ...payload,
      });
    } else {
      onAddInvoice(payload);
    }
    closeModal();
  };

  const filteredInvoices = useMemo(() => {
    const q = search.trim().toLowerCase();
    return invoices
      .filter((inv) => {
        if (taxFilter !== 'ALL' && inv.taxCode !== taxFilter) return false;
        if (statusFilter !== 'ALL' && inv.status !== statusFilter) return false;
        if (!q) return true;
        return (
          inv.invoiceNumber.toLowerCase().includes(q) ||
          inv.clientName.toLowerCase().includes(q) ||
          inv.description.toLowerCase().includes(q) ||
          (inv.clientNif || '').toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (sortBy === 'oldest') return a.date.localeCompare(b.date);
        if (sortBy === 'highest') return b.amountTTC - a.amountTTC;
        return b.date.localeCompare(a.date);
      });
  }, [invoices, search, taxFilter, statusFilter, sortBy]);

  const statusBadgeStyle = (status: InvoiceStatus) => {
    if (status === 'paid') return 'text-emerald-700 dark:text-emerald-400';
    if (status === 'pending') return 'text-[#B3861D] dark:text-[#E5C158]';
    return 'text-slate-500 dark:text-emerald-300/60';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-[#063B2C] dark:text-white">
            {t.invoices.title}
          </h2>
          <p className="text-sm text-slate-600 dark:text-emerald-200/75 mt-1">
            {t.invoices.subtitle}
          </p>
        </div>

        <button
          type="button"
          onClick={openNewModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors self-start sm:self-auto whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>{t.actions.newInvoice}</span>
        </button>
      </div>

      {/* Filter & Search Secondary Card */}
      <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3">
        <div className="lg:col-span-5 relative">
          <Search className="w-4 h-4 text-emerald-700/60 dark:text-emerald-300/60 absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.invoices.searchPlaceholder}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] ps-10 pe-3.5 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />
        </div>

        <div className="lg:col-span-3">
          <select
            value={taxFilter}
            onChange={(e) => setTaxFilter(e.target.value)}
            aria-label={t.invoices.colTax}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="ALL">{t.invoices.allTaxes}</option>
            {Array.from(new Set(taxRules.map((r) => r.code))).map((code) => (
              <option key={code} value={code}>
                {code}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            aria-label={t.invoices.colStatus}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="ALL">{t.invoices.allStatuses}</option>
            <option value="paid">{t.invoices.statusLabels.paid}</option>
            <option value="pending">{t.invoices.statusLabels.pending}</option>
            <option value="draft">{t.invoices.statusLabels.draft}</option>
          </select>
        </div>

        <div className="lg:col-span-2">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest' | 'highest')}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="newest">{t.invoices.sortNewest}</option>
            <option value="oldest">{t.invoices.sortOldest}</option>
            <option value="highest">{t.invoices.sortHighest}</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden">
        {filteredInvoices.length === 0 ? (
          <div className="py-14 px-6 text-center">
            <FileText className="w-10 h-10 text-emerald-600/40 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-[#063B2C] dark:text-white">
              {t.invoices.emptyTitle}
            </h3>
            <p className="text-sm text-slate-600 dark:text-emerald-200/70 mt-1 max-w-md mx-auto">
              {t.invoices.emptyDesc}
            </p>
            <button
              type="button"
              onClick={openNewModal}
              className="mt-4 px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-600 text-white"
            >
              {t.actions.newInvoice}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/80 dark:bg-[#0E2B22] text-xs text-[#0A4A37] dark:text-emerald-200/80">
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colNumber}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colClient}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colDate}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colTax}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colHt}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTaxAmt}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTtc}</th>
                  <th className="py-3 px-4 text-start font-semibold">{t.invoices.colStatus}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colActions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
                {filteredInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    className="hover:bg-[#FAF9F5] dark:hover:bg-[#0E2B22]/60 transition-colors"
                  >
                    <td className="py-3 px-4 font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-[#063B2C] dark:text-emerald-50 max-w-[200px] truncate">
                        {inv.clientName}
                      </div>
                      <div className="text-xs text-slate-600 dark:text-emerald-200/70 max-w-[200px] truncate">
                        {inv.description}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono-num text-slate-600 dark:text-emerald-200/75 whitespace-nowrap">
                      {inv.date}
                    </td>
                    <td className="py-3 px-4 font-mono-num text-[#063B2C] dark:text-emerald-100 whitespace-nowrap">
                      {inv.taxCode} · {inv.taxRate}%
                    </td>
                    <td className="py-3 px-4 text-end font-mono-num text-slate-700 dark:text-emerald-100 whitespace-nowrap">
                      {formatDzd(inv.amountHT, lang, currencyDisplay)}
                    </td>
                    <td className="py-3 px-4 text-end font-mono-num text-emerald-700 dark:text-emerald-400 font-semibold whitespace-nowrap">
                      {formatDzd(inv.taxAmount, lang, currencyDisplay)}
                    </td>
                    <td className="py-3 px-4 text-end font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                      {formatDzd(inv.amountTTC, lang, currencyDisplay)}
                    </td>
                    <td className={`py-3 px-4 text-xs font-semibold whitespace-nowrap ${statusBadgeStyle(inv.status)}`}>
                      {t.invoices.statusLabels[inv.status]}
                    </td>
                    <td className="py-3 px-4 text-end whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setViewingInvoice(inv)}
                          className="p-1.5 rounded-md text-slate-500 hover:text-[#063B2C] dark:hover:text-white hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22]"
                          title={t.actions.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingInvoice(inv)}
                          className="p-1.5 rounded-md text-slate-500 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22]"
                          title={t.actions.edit}
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(inv.id)}
                          className="p-1.5 rounded-md text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22]"
                          title={t.actions.delete}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Invoice Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#03120D]/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#0A221B] border border-[#E3E6E0] dark:border-[#163D32] rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-xl">
            <div className="px-6 py-4 border-b border-[#E3E6E0] dark:border-[#163D32] flex items-center justify-between">
              <h3 className="text-lg font-bold text-[#063B2C] dark:text-white">
                {editingInvoice ? t.invoices.modalEditTitle : t.invoices.modalAddTitle}
              </h3>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 rounded-lg text-slate-400 hover:text-[#063B2C] dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldNumber} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formNumber}
                    onChange={(e) => setFormNumber(e.target.value)}
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldDate} *
                  </label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldClient} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formClient}
                    onChange={(e) => setFormClient(e.target.value)}
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldNif}
                  </label>
                  <input
                    type="text"
                    value={formNif}
                    onChange={(e) => setFormNif(e.target.value)}
                    placeholder="001616098451234"
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                  {t.invoices.fieldDescription} *
                </label>
                <input
                  type="text"
                  required
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldTaxType}
                  </label>
                  <select
                    value={formRuleId}
                    onChange={(e) => handleRuleSelect(e.target.value)}
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  >
                    {taxRules.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.code} — {lang === 'ar' ? r.nameAr : r.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldRate}
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    required
                    value={formRate}
                    onChange={(e) => setFormRate(e.target.value)}
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                    {t.invoices.fieldStatus}
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as InvoiceStatus)}
                    className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value="paid">{t.invoices.statusLabels.paid}</option>
                    <option value="pending">{t.invoices.statusLabels.pending}</option>
                    <option value="draft">{t.invoices.statusLabels.draft}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                  {t.invoices.fieldAmountHt} *
                </label>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  required
                  value={formAmountHt}
                  onChange={(e) => setFormAmountHt(e.target.value)}
                  className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm font-mono-num text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="rounded-lg bg-[#F1F2EE] dark:bg-[#0E2B22] border border-[#E0E3DD] dark:border-[#1B493C] p-4 grid grid-cols-3 gap-3 text-xs">
                <div>
                  <div className="text-slate-600 dark:text-emerald-200/75">{t.invoices.colHt}</div>
                  <div className="mt-1 font-mono-num font-semibold text-[#063B2C] dark:text-white">
                    {formatDzd(liveCalc.amountHT, lang, currencyDisplay)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-600 dark:text-emerald-200/75">{t.invoices.colTaxAmt}</div>
                  <div className="mt-1 font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158]">
                    {formatDzd(liveCalc.taxAmount, lang, currencyDisplay)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-600 dark:text-emerald-200/75">{t.invoices.colTtc}</div>
                  <div className="mt-1 font-mono-num font-bold text-[#063B2C] dark:text-white">
                    {formatDzd(liveCalc.amountTTC, lang, currencyDisplay)}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1">
                  {t.invoices.fieldNotes}
                </label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-[#FAF9F5] dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 rounded-lg text-sm font-medium border border-[#D4D9D2] dark:border-[#1B493C] text-[#063B2C] dark:text-emerald-100 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22]"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  {t.actions.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Invoice Modal */}
      {viewingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#03120D]/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#0A221B] border border-[#E3E6E0] dark:border-[#163D32] rounded-xl w-full max-w-lg shadow-xl overflow-hidden">
            <div className="bg-[#052E22] text-white px-6 py-4 flex items-center justify-between border-b border-[#D4AF37]/40">
              <div>
                <div className="text-xs text-[#E5C158] font-semibold">{t.invoices.modalViewTitle}</div>
                <div className="text-lg font-bold font-mono-num">{viewingInvoice.invoiceNumber}</div>
              </div>
              <button
                type="button"
                onClick={() => setViewingInvoice(null)}
                className="p-1 text-emerald-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-slate-500 dark:text-emerald-200/70">{t.invoices.colClient}</div>
                  <div className="font-semibold text-[#063B2C] dark:text-white mt-0.5">
                    {viewingInvoice.clientName}
                  </div>
                  {viewingInvoice.clientNif && (
                    <div className="text-xs font-mono-num text-slate-500 dark:text-emerald-200/70 mt-0.5">
                      NIF: {viewingInvoice.clientNif}
                    </div>
                  )}
                </div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-emerald-200/70">{t.invoices.colDate}</div>
                  <div className="font-mono-num font-medium text-[#063B2C] dark:text-white mt-0.5">
                    {viewingInvoice.date}
                  </div>
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500 dark:text-emerald-200/70">{t.invoices.fieldDescription}</div>
                <div className="text-[#063B2C] dark:text-emerald-100 mt-0.5">{viewingInvoice.description}</div>
              </div>

              <div className="border-t border-b border-[#E3E6E0] dark:border-[#163D32] py-3 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-emerald-200/75">{t.invoices.colHt}</span>
                  <span className="font-mono-num font-medium">
                    {formatDzd(viewingInvoice.amountHT, lang, currencyDisplay)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-emerald-200/75">
                    {viewingInvoice.taxCode} ({viewingInvoice.taxRate}%)
                  </span>
                  <span className="font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158]">
                    {formatDzd(viewingInvoice.taxAmount, lang, currencyDisplay)}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold pt-1">
                  <span>{t.invoices.colTtc}</span>
                  <span className="font-mono-num text-[#063B2C] dark:text-white">
                    {formatDzd(viewingInvoice.amountTTC, lang, currencyDisplay)}
                  </span>
                </div>
              </div>

              {viewingInvoice.notes && (
                <div>
                  <div className="text-xs text-slate-500 dark:text-emerald-200/70">{t.invoices.fieldNotes}</div>
                  <p className="text-xs text-slate-600 dark:text-emerald-200/80 mt-1">{viewingInvoice.notes}</p>
                </div>
              )}

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setViewingInvoice(null)}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#F1F2EE] dark:bg-[#0E2B22] text-[#063B2C] dark:text-emerald-100"
                >
                  {t.actions.close}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {confirmDeleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#03120D]/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#0A221B] border border-[#E3E6E0] dark:border-[#163D32] rounded-xl w-full max-w-md p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
              {t.actions.confirmDelete}
            </h3>
            <p className="text-sm text-slate-600 dark:text-emerald-200/80">
              {t.invoices.deleteConfirmMsg}
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmDeleteId(null)}
                className="px-4 py-2 rounded-lg text-sm font-medium border border-[#D4D9D2] dark:border-[#1B493C] text-[#063B2C] dark:text-emerald-100"
              >
                {t.actions.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteInvoice(confirmDeleteId);
                  setConfirmDeleteId(null);
                }}
                className="px-4 py-2 rounded-lg text-sm font-semibold bg-rose-600 hover:bg-rose-500 text-white"
              >
                {t.actions.delete}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
