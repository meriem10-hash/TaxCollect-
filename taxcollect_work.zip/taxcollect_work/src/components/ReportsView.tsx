import React, { useEffect, useMemo, useState } from 'react';
import {
  FileDown,
  Printer,
  FileSpreadsheet,
  Info,
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Share2,
  AlertCircle,
} from 'lucide-react';
import { Invoice, Language, TaxRuleConfig } from '../types';
import { getT } from '../i18n/translations';
import { formatDzd, formatMonthLabel, roundMoney } from '../utils/taxMath';
import {
  exportAnnualReportPdf,
  exportInvoicesCsv,
  exportMonthlyReportPdf,
  exportTaxReportPdf,
  PdfExportResult,
} from '../utils/pdfExport';

interface ReportsViewProps {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  entityName: string;
  entityNif: string;
  invoices: Invoice[];
  taxRules: TaxRuleConfig[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  lang,
  currencyDisplay,
  entityName,
  entityNif,
  invoices,
  taxRules,
}) => {
  const t = getT(lang);
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL');
  const [selectedTax, setSelectedTax] = useState<string>('ALL');
  const [selectedYear, setSelectedYear] = useState<string>('');
  const [activeDetailMonth, setActiveDetailMonth] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportMsg, setExportMsg] = useState('');
  const [exportError, setExportError] = useState('');
  const [lastPdfDownload, setLastPdfDownload] = useState<PdfExportResult | null>(null);

  useEffect(() => {
    return () => {
      if (lastPdfDownload?.blobUrl) {
        URL.revokeObjectURL(lastPdfDownload.blobUrl);
      }
    };
  }, [lastPdfDownload]);

  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    invoices.forEach((inv) => {
      if (inv.date.length >= 7) set.add(inv.date.slice(0, 7));
    });
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [invoices]);

  const availableYears = useMemo(() => {
    const set = new Set<string>();
    invoices.forEach((inv) => {
      if (inv.date.length >= 4) set.add(inv.date.slice(0, 4));
    });
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [invoices]);

  const effectiveYear = availableYears.includes(selectedYear)
    ? selectedYear
    : availableYears[0] || String(new Date().getFullYear());

  const filtered = useMemo(() => {
    return invoices.filter((inv) => {
      if (selectedMonth !== 'ALL' && !inv.date.startsWith(selectedMonth)) return false;
      if (selectedTax !== 'ALL' && inv.taxCode !== selectedTax) return false;
      return true;
    });
  }, [invoices, selectedMonth, selectedTax]);

  const totals = useMemo(() => {
    const ht = filtered.reduce((sum, i) => sum + i.amountHT, 0);
    const tax = filtered.reduce((sum, i) => sum + i.taxAmount, 0);
    const ttc = filtered.reduce((sum, i) => sum + i.amountTTC, 0);
    return {
      ht: roundMoney(ht),
      tax: roundMoney(tax),
      ttc: roundMoney(ttc),
      count: filtered.length,
    };
  }, [filtered]);

  const monthlyRows = useMemo(() => {
    const map = new Map<string, { month: string; count: number; ht: number; tax: number; ttc: number }>();
    filtered.forEach((inv) => {
      const ym = inv.date.slice(0, 7);
      const curr = map.get(ym) || { month: ym, count: 0, ht: 0, tax: 0, ttc: 0 };
      curr.count += 1;
      curr.ht = roundMoney(curr.ht + inv.amountHT);
      curr.tax = roundMoney(curr.tax + inv.taxAmount);
      curr.ttc = roundMoney(curr.ttc + inv.amountTTC);
      map.set(ym, curr);
    });
    return Array.from(map.values()).sort((a, b) => b.month.localeCompare(a.month));
  }, [filtered]);

  const categoryRows = useMemo(() => {
    const map = new Map<string, { code: string; count: number; ht: number; tax: number }>();
    filtered.forEach((inv) => {
      const curr = map.get(inv.taxCode) || { code: inv.taxCode, count: 0, ht: 0, tax: 0 };
      curr.count += 1;
      curr.ht = roundMoney(curr.ht + inv.amountHT);
      curr.tax = roundMoney(curr.tax + inv.taxAmount);
      map.set(inv.taxCode, curr);
    });
    const totalTax = totals.tax || 1;
    return Array.from(map.values())
      .map((row) => {
        const rule = taxRules.find((r) => r.code === row.code);
        return {
          ...row,
          name: rule ? (lang === 'ar' ? rule.nameAr : rule.nameEn) : row.code,
          effectiveDate: rule?.effectiveDate || '—',
          share: roundMoney((row.tax / totalTax) * 100),
        };
      })
      .sort((a, b) => b.tax - a.tax);
  }, [filtered, totals.tax, taxRules, lang]);

  const activeMonthSummary = useMemo(() => {
    if (!activeDetailMonth) return null;
    return monthlyRows.find((m) => m.month === activeDetailMonth) || null;
  }, [activeDetailMonth, monthlyRows]);

  const activeMonthInvoices = useMemo(() => {
    if (!activeDetailMonth) return [];
    return filtered
      .filter((inv) => inv.date.startsWith(activeDetailMonth))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [activeDetailMonth, filtered]);

  const activeMonthTotals = useMemo(() => {
    const ht = activeMonthInvoices.reduce((sum, i) => sum + i.amountHT, 0);
    const tax = activeMonthInvoices.reduce((sum, i) => sum + i.taxAmount, 0);
    const ttc = activeMonthInvoices.reduce((sum, i) => sum + i.amountTTC, 0);
    return {
      ht: roundMoney(ht),
      tax: roundMoney(tax),
      ttc: roundMoney(ttc),
      count: activeMonthInvoices.length,
    };
  }, [activeMonthInvoices]);

  const handleExportPdf = async () => {
    setExporting(true);
    setExportMsg('');
    setExportError('');
    try {
      if (filtered.length === 0) {
        throw new Error(t.reports.noInvoicesToExport);
      }
      const result = await exportTaxReportPdf({
        lang,
        currencyDisplay,
        entityName,
        entityNif,
        periodLabel:
          selectedMonth === 'ALL' ? t.reports.allPeriods : formatMonthLabel(selectedMonth, lang),
        invoices: filtered,
        taxRules,
        totals,
        monthlyRows,
        categoryRows,
      });
      setLastPdfDownload(result);
      setExportMsg(t.reports.pdfSuccess);
    } catch (err) {
      setLastPdfDownload(null);
      setExportError(err instanceof Error ? err.message : 'PDF export failed');
    } finally {
      setExporting(false);
    }
  };

  const handleExportMonthlyPdf = async (monthToExport: string) => {
    if (!monthToExport) return;
    setExporting(true);
    setExportMsg('');
    setExportError('');
    try {
      const monthInvoices = invoices
        .filter((inv) => {
          if (!inv.date.startsWith(monthToExport)) return false;
          if (selectedTax !== 'ALL' && inv.taxCode !== selectedTax) return false;
          return true;
        })
        .sort((a, b) => b.date.localeCompare(a.date));

      if (monthInvoices.length === 0) {
        throw new Error(t.reports.noInvoicesToExport);
      }

      const monthTotals = {
        ht: roundMoney(monthInvoices.reduce((sum, i) => sum + i.amountHT, 0)),
        tax: roundMoney(monthInvoices.reduce((sum, i) => sum + i.taxAmount, 0)),
        ttc: roundMoney(monthInvoices.reduce((sum, i) => sum + i.amountTTC, 0)),
        count: monthInvoices.length,
      };

      const result = await exportMonthlyReportPdf({
        lang,
        currencyDisplay,
        entityName,
        entityNif,
        month: monthToExport,
        taxFilter: selectedTax,
        totals: monthTotals,
        invoices: monthInvoices,
      });
      setLastPdfDownload(result);
      setExportMsg(t.reports.monthlyPdfSuccess);
    } catch (err) {
      setLastPdfDownload(null);
      setExportError(err instanceof Error ? err.message : 'Monthly PDF export failed');
    } finally {
      setExporting(false);
    }
  };

  const handleExportAnnualPdf = async () => {
    setExporting(true);
    setExportMsg('');
    setExportError('');
    try {
      const yearInvoices = invoices
        .filter((inv) => {
          if (!inv.date.startsWith(effectiveYear)) return false;
          if (selectedTax !== 'ALL' && inv.taxCode !== selectedTax) return false;
          return true;
        })
        .sort((a, b) => b.date.localeCompare(a.date));

      if (yearInvoices.length === 0) {
        throw new Error(t.reports.noInvoicesToExport);
      }

      const yearTotals = {
        ht: roundMoney(yearInvoices.reduce((sum, i) => sum + i.amountHT, 0)),
        tax: roundMoney(yearInvoices.reduce((sum, i) => sum + i.taxAmount, 0)),
        ttc: roundMoney(yearInvoices.reduce((sum, i) => sum + i.amountTTC, 0)),
        count: yearInvoices.length,
      };

      const mMap = new Map<
        string,
        { month: string; count: number; ht: number; tax: number; ttc: number }
      >();
      yearInvoices.forEach((inv) => {
        const ym = inv.date.slice(0, 7);
        const curr = mMap.get(ym) || { month: ym, count: 0, ht: 0, tax: 0, ttc: 0 };
        curr.count += 1;
        curr.ht = roundMoney(curr.ht + inv.amountHT);
        curr.tax = roundMoney(curr.tax + inv.taxAmount);
        curr.ttc = roundMoney(curr.ttc + inv.amountTTC);
        mMap.set(ym, curr);
      });
      const yearMonthlyRows = Array.from(mMap.values()).sort((a, b) =>
        a.month.localeCompare(b.month)
      );

      const cMap = new Map<string, { code: string; count: number; ht: number; tax: number }>();
      yearInvoices.forEach((inv) => {
        const curr = cMap.get(inv.taxCode) || { code: inv.taxCode, count: 0, ht: 0, tax: 0 };
        curr.count += 1;
        curr.ht = roundMoney(curr.ht + inv.amountHT);
        curr.tax = roundMoney(curr.tax + inv.taxAmount);
        cMap.set(inv.taxCode, curr);
      });
      const totalYearTax = yearTotals.tax || 1;
      const yearCategoryRows = Array.from(cMap.values())
        .map((row) => {
          const rule = taxRules.find((r) => r.code === row.code);
          return {
            ...row,
            name: rule ? (lang === 'ar' ? rule.nameAr : rule.nameEn) : row.code,
            effectiveDate: rule?.effectiveDate || '—',
            share: roundMoney((row.tax / totalYearTax) * 100),
          };
        })
        .sort((a, b) => b.tax - a.tax);

      const result = await exportAnnualReportPdf({
        lang,
        currencyDisplay,
        entityName,
        entityNif,
        year: effectiveYear,
        taxFilter: selectedTax,
        totals: yearTotals,
        monthlyRows: yearMonthlyRows,
        categoryRows: yearCategoryRows,
        invoices: yearInvoices,
      });
      setLastPdfDownload(result);
      setExportMsg(t.reports.annualPdfSuccess);
    } catch (err) {
      setLastPdfDownload(null);
      setExportError(err instanceof Error ? err.message : 'Annual PDF export failed');
    } finally {
      setExporting(false);
    }
  };

  const canNativeSharePdf = useMemo(() => {
    if (!lastPdfDownload || typeof navigator === 'undefined' || !navigator.share || !navigator.canShare) {
      return false;
    }
    try {
      const testFile = new File([lastPdfDownload.blob], lastPdfDownload.filename, {
        type: 'application/pdf',
      });
      return navigator.canShare({ files: [testFile] });
    } catch {
      return false;
    }
  }, [lastPdfDownload]);

  const handleSharePdf = async () => {
    if (!lastPdfDownload || !navigator.share) return;
    try {
      const file = new File([lastPdfDownload.blob], lastPdfDownload.filename, {
        type: 'application/pdf',
      });
      await navigator.share({
        title: lastPdfDownload.filename,
        files: [file],
      });
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') return;
      setExportError(err instanceof Error ? err.message : 'Unable to share PDF');
    }
  };

  return (
    <div className="space-y-6 print-container">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 no-print">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-[#063B2C] dark:text-white">
            {t.reports.title}
          </h2>
          <p className="text-sm text-slate-600 dark:text-emerald-200/75 mt-1">
            {t.reports.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => exportInvoicesCsv(filtered)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22] whitespace-nowrap"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t.actions.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium border border-[#DCE0D9] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#F1F2EE] dark:hover:bg-[#0E2B22] whitespace-nowrap"
          >
            <Printer className="w-4 h-4" />
            <span>{t.actions.printReport}</span>
          </button>

          <button
            type="button"
            disabled={exporting}
            onClick={handleExportPdf}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white whitespace-nowrap"
          >
            <FileDown className="w-4 h-4" />
            <span>{exporting ? t.reports.exportingPdf : t.actions.exportPdf}</span>
          </button>

          <div className="inline-flex items-center rounded-lg border border-[#D4AF37]/50 bg-[#052E22] overflow-hidden">
            {availableYears.length > 0 && (
              <select
                value={effectiveYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                aria-label={t.reports.annualYearLabel}
                className="bg-[#063B2C] text-[#FDE68A] font-mono-num text-xs sm:text-sm font-semibold px-2.5 py-2 border-e border-[#D4AF37]/30 focus:outline-none"
              >
                {availableYears.map((yr) => (
                  <option key={yr} value={yr}>
                    {yr}
                  </option>
                ))}
              </select>
            )}
            <button
              type="button"
              disabled={exporting}
              onClick={handleExportAnnualPdf}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white hover:bg-[#084534] disabled:opacity-60 whitespace-nowrap transition-colors"
            >
              <FileDown className="w-4 h-4 text-[#E5C158]" />
              <span>{exporting ? t.reports.exportingPdf : t.reports.exportAnnualPdf}</span>
            </button>
          </div>
        </div>
      </div>

      {exportMsg && (
        <div className="rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm text-emerald-900 dark:text-emerald-200 no-print">
          <div className="flex items-center gap-2 min-w-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span className="font-medium">{exportMsg}</span>
            {lastPdfDownload && (
              <span className="font-mono-num text-xs opacity-80 truncate">
                ({lastPdfDownload.filename})
              </span>
            )}
          </div>

          {lastPdfDownload && (
            <div className="flex items-center gap-2 flex-wrap shrink-0">
              <a
                href={lastPdfDownload.blobUrl}
                download={lastPdfDownload.filename}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white transition-colors whitespace-nowrap"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>{t.reports.downloadAgain}</span>
              </a>

              {canNativeSharePdf && (
                <button
                  type="button"
                  onClick={handleSharePdf}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-emerald-100/60 dark:hover:bg-[#0E2B22] transition-colors whitespace-nowrap"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{t.reports.sharePdf}</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {exportError && (
        <div className="rounded-lg border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 px-4 py-3 flex items-center gap-2 text-xs sm:text-sm text-rose-800 dark:text-rose-200 no-print">
          <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
          <span>
            {t.reports.exportFailedPrefix} {exportError}
          </span>
        </div>
      )}

      {/* Filters Secondary Card */}
      <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 no-print">
        <div>
          <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1.5">
            {t.reports.periodLabel}
          </label>
          <select
            value={selectedMonth}
            onChange={(e) => {
              setSelectedMonth(e.target.value);
              setActiveDetailMonth(null);
            }}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="ALL">{t.reports.allPeriods}</option>
            {availableMonths.map((ym) => (
              <option key={ym} value={ym}>
                {formatMonthLabel(ym, lang)}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-[#063B2C] dark:text-emerald-100 mb-1.5">
            {t.reports.taxFilterLabel}
          </label>
          <select
            value={selectedTax}
            onChange={(e) => setSelectedTax(e.target.value)}
            className="w-full rounded-lg border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#061A14] px-3 py-2 text-sm text-[#063B2C] dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="ALL">{t.invoices.allTaxes}</option>
            {Array.from(new Set(taxRules.map((r) => r.code))).map((code) => (
              <option key={code} value={code}>
                {code}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-2 flex items-end justify-between border-t sm:border-t-0 pt-3 sm:pt-0 border-[#DCE0D9] dark:border-[#1B493C] text-xs text-slate-600 dark:text-emerald-200/75">
          <div>
            <div>
              {t.reports.entityLabel}:{' '}
              <span className="font-semibold text-[#063B2C] dark:text-white">
                {entityName}
              </span>
            </div>
            {entityNif && (
              <div className="font-mono-num mt-0.5">
                {t.reports.nifLabel}: {entityNif}
              </div>
            )}
          </div>
          <div className="font-mono-num">
            {t.reports.generatedOn}: {new Date().toISOString().slice(0, 10)}
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-5">
          <div className="text-xs text-slate-600 dark:text-emerald-200/75">{t.reports.summaryHt}</div>
          <div className="mt-2 text-xl font-bold font-mono-num text-[#063B2C] dark:text-white">
            {formatDzd(totals.ht, lang, currencyDisplay)}
          </div>
        </div>

        <div className="bg-[#052E22] text-white rounded-xl border border-[#D4AF37]/40 p-5">
          <div className="text-xs text-emerald-100">{t.reports.summaryTax}</div>
          <div className="mt-2 text-xl font-bold font-mono-num text-[#FDE68A]">
            {formatDzd(totals.tax, lang, currencyDisplay)}
          </div>
        </div>

        <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-5">
          <div className="text-xs text-slate-600 dark:text-emerald-200/75">{t.reports.summaryTtc}</div>
          <div className="mt-2 text-xl font-bold font-mono-num text-[#063B2C] dark:text-white">
            {formatDzd(totals.ttc, lang, currencyDisplay)}
          </div>
        </div>

        <div className="bg-[#F1F2EE] dark:bg-[#0E2B22] rounded-xl border border-[#E0E3DD] dark:border-[#1B493C] p-5">
          <div className="text-xs text-slate-600 dark:text-emerald-200/75">{t.reports.summaryCount}</div>
          <div className="mt-2 text-xl font-bold font-mono-num text-[#063B2C] dark:text-white">
            {totals.count}
          </div>
        </div>
      </section>

      {/* Monthly Breakdown Table / Selected Month Invoices Drill-Down */}
      {!activeDetailMonth ? (
        <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden">
          <div className="px-5 py-4 border-b border-[#E3E6E0] dark:border-[#163D32] flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
            <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
              {t.reports.monthlyBreakdown}
            </h3>
            {monthlyRows.length > 0 && (
              <span className="text-xs text-[#4B635B] dark:text-emerald-200/70">
                {t.reports.clickMonthHint}
              </span>
            )}
          </div>
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/80 dark:bg-[#0E2B22] text-xs text-[#0A4A37] dark:text-emerald-200/80">
                  <th className="py-3 px-5 text-start font-semibold">{t.reports.colMonth}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.reports.colCount}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colHt}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTaxAmt}</th>
                  <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTtc}</th>
                  <th className="py-3 px-5 text-end font-semibold no-print">{t.invoices.colActions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
                {monthlyRows.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500 dark:text-emerald-200/70">
                      {t.dashboard.noData}
                    </td>
                  </tr>
                ) : (
                  monthlyRows.map((m) => (
                    <tr
                      key={m.month}
                      onClick={() => setActiveDetailMonth(m.month)}
                      className="cursor-pointer transition-colors hover:bg-[#FAF9F5] dark:hover:bg-[#0E2B22]/60 group"
                    >
                      <td className="py-3 px-5 font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDetailMonth(m.month);
                          }}
                          className="inline-flex items-center gap-2 text-start font-semibold text-[#063B2C] dark:text-white group-hover:text-emerald-700 dark:group-hover:text-[#E5C158] focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 rounded"
                          aria-label={`${t.reports.viewMonthInvoices}: ${formatMonthLabel(m.month, lang)}`}
                        >
                          <span>{formatMonthLabel(m.month, lang)}</span>
                          {lang === 'ar' ? (
                            <ChevronLeft className="w-4 h-4 text-emerald-600 dark:text-[#E5C158] opacity-75 group-hover:opacity-100 transition-opacity shrink-0" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-emerald-600 dark:text-[#E5C158] opacity-75 group-hover:opacity-100 transition-opacity shrink-0" />
                          )}
                        </button>
                      </td>
                      <td className="py-3 px-4 text-end font-mono-num text-slate-600 dark:text-emerald-200/80 whitespace-nowrap">
                        {m.count}
                      </td>
                      <td className="py-3 px-4 text-end font-mono-num text-[#063B2C] dark:text-emerald-100 whitespace-nowrap">
                        {formatDzd(m.ht, lang, currencyDisplay)}
                      </td>
                      <td className="py-3 px-4 text-end font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158] whitespace-nowrap">
                        {formatDzd(m.tax, lang, currencyDisplay)}
                      </td>
                      <td className="py-3 px-4 text-end font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                        {formatDzd(m.ttc, lang, currencyDisplay)}
                      </td>
                      <td className="py-3 px-5 text-end whitespace-nowrap no-print">
                        <button
                          type="button"
                          disabled={exporting}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleExportMonthlyPdf(m.month);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white transition-colors whitespace-nowrap"
                        >
                          <FileDown className="w-3.5 h-3.5 text-[#FDE68A]" />
                          <span>{t.reports.exportMonthlyPdf}</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Responsive Monthly Summary List */}
          <div className="md:hidden divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
            {monthlyRows.length === 0 ? (
              <div className="py-8 px-4 text-center text-sm text-slate-500 dark:text-emerald-200/70">
                {t.dashboard.noData}
              </div>
            ) : (
              monthlyRows.map((m) => (
                <div key={m.month} className="p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveDetailMonth(m.month)}
                      className="inline-flex items-center gap-1.5 font-bold text-base text-[#063B2C] dark:text-white hover:text-emerald-700 dark:hover:text-[#E5C158]"
                    >
                      <span>{formatMonthLabel(m.month, lang)}</span>
                      {lang === 'ar' ? (
                        <ChevronLeft className="w-4 h-4 text-emerald-600 dark:text-[#E5C158]" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-emerald-600 dark:text-[#E5C158]" />
                      )}
                    </button>
                    <span className="font-mono-num text-xs text-slate-600 dark:text-emerald-200/80">
                      {m.count} {t.reports.colCount}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <div className="text-[11px] text-[#4B635B] dark:text-emerald-200/70">
                        {t.invoices.colHt}
                      </div>
                      <div className="font-mono-num font-medium text-[#063B2C] dark:text-emerald-100 mt-0.5">
                        {formatDzd(m.ht, lang, currencyDisplay)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[#4B635B] dark:text-emerald-200/70">
                        {t.invoices.colTaxAmt}
                      </div>
                      <div className="font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158] mt-0.5">
                        {formatDzd(m.tax, lang, currencyDisplay)}
                      </div>
                    </div>
                    <div className="text-end">
                      <div className="text-[11px] text-[#4B635B] dark:text-emerald-200/70">
                        {t.invoices.colTtc}
                      </div>
                      <div className="font-mono-num font-bold text-[#063B2C] dark:text-white mt-0.5">
                        {formatDzd(m.ttc, lang, currencyDisplay)}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1 no-print">
                    <button
                      type="button"
                      onClick={() => setActiveDetailMonth(m.month)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border border-[#D4D9D2] dark:border-[#1B493C] bg-[#F1F2EE] dark:bg-[#0E2B22] text-[#063B2C] dark:text-emerald-100 whitespace-nowrap"
                    >
                      <span>{t.reports.viewMonthInvoices}</span>
                    </button>
                    <button
                      type="button"
                      disabled={exporting}
                      onClick={() => handleExportMonthlyPdf(m.month)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white whitespace-nowrap"
                    >
                      <FileDown className="w-3.5 h-3.5 text-[#FDE68A]" />
                      <span>{t.reports.exportMonthlyPdf}</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>
      ) : (
        <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden">
          {/* Header with Back to Monthly Summary */}
          <div className="px-5 py-4 border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/70 dark:bg-[#0E2B22]/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
                {t.reports.monthInvoicesTitle} {formatMonthLabel(activeDetailMonth, lang)}
              </h3>
              {activeMonthSummary && (
                <div className="mt-1 text-xs text-[#4B635B] dark:text-emerald-200/80 flex items-center gap-2 flex-wrap font-mono-num">
                  <span>
                    {activeMonthSummary.count} {t.reports.colCount}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {t.invoices.colHt}: {formatDzd(activeMonthSummary.ht, lang, currencyDisplay)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold text-emerald-700 dark:text-[#E5C158]">
                    {t.invoices.colTaxAmt}: {formatDzd(activeMonthSummary.tax, lang, currencyDisplay)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold text-[#063B2C] dark:text-white">
                    {t.invoices.colTtc}: {formatDzd(activeMonthSummary.ttc, lang, currencyDisplay)}
                  </span>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto no-print">
              <button
                type="button"
                disabled={exporting}
                onClick={() => handleExportMonthlyPdf(activeDetailMonth)}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white transition-colors whitespace-nowrap shrink-0"
              >
                <FileDown className="w-4 h-4 text-[#FDE68A]" />
                <span>{exporting ? t.reports.exportingPdf : t.reports.exportMonthlyPdf}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveDetailMonth(null)}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold border border-[#D4D9D2] dark:border-[#1B493C] bg-white dark:bg-[#0A221B] text-[#063B2C] dark:text-emerald-100 hover:bg-[#FAF9F5] dark:hover:bg-[#14392E] transition-colors whitespace-nowrap shrink-0"
              >
                {lang === 'ar' ? (
                  <ArrowRight className="w-4 h-4 text-emerald-600 dark:text-[#E5C158]" />
                ) : (
                  <ArrowLeft className="w-4 h-4 text-emerald-600 dark:text-[#E5C158]" />
                )}
                <span>{t.reports.backToMonthlySummary}</span>
              </button>
            </div>
          </div>

          {activeMonthInvoices.length === 0 ? (
            <div className="py-10 px-5 text-center text-sm text-slate-500 dark:text-emerald-200/70">
              {t.reports.noMonthInvoices}
            </div>
          ) : (
            <>
              {/* Desktop / Tablet Table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/80 dark:bg-[#0E2B22] text-xs text-[#0A4A37] dark:text-emerald-200/80">
                      <th className="py-3 px-5 text-start font-semibold">{t.invoices.colNumber}</th>
                      <th className="py-3 px-4 text-start font-semibold">{t.invoices.colDate}</th>
                      <th className="py-3 px-4 text-start font-semibold">{t.invoices.fieldTaxType}</th>
                      <th className="py-3 px-4 text-end font-semibold">{t.invoices.colHt}</th>
                      <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTaxAmt}</th>
                      <th className="py-3 px-5 text-end font-semibold">{t.invoices.colTtc}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
                    {activeMonthInvoices.map((inv) => (
                      <tr
                        key={inv.id}
                        className="hover:bg-[#FAF9F5] dark:hover:bg-[#0E2B22]/60"
                      >
                        <td className="py-3 px-5 font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                          {inv.invoiceNumber}
                        </td>
                        <td className="py-3 px-4 font-mono-num text-slate-600 dark:text-emerald-200/80 whitespace-nowrap">
                          {inv.date}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap text-[#063B2C] dark:text-emerald-100">
                          <span className="font-semibold">{inv.taxCode}</span>
                          <span className="text-slate-400 mx-1.5" aria-hidden="true">·</span>
                          <span className="font-mono-num text-xs text-slate-600 dark:text-emerald-200/75">
                            {inv.taxRate}%
                          </span>
                        </td>
                        <td className="py-3 px-4 text-end font-mono-num text-[#063B2C] dark:text-emerald-100 whitespace-nowrap">
                          {formatDzd(inv.amountHT, lang, currencyDisplay)}
                        </td>
                        <td className="py-3 px-4 text-end font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158] whitespace-nowrap">
                          {formatDzd(inv.taxAmount, lang, currencyDisplay)}
                        </td>
                        <td className="py-3 px-5 text-end font-mono-num font-semibold text-[#063B2C] dark:text-white whitespace-nowrap">
                          {formatDzd(inv.amountTTC, lang, currencyDisplay)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Responsive List */}
              <div className="md:hidden divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
                {activeMonthInvoices.map((inv) => (
                  <div key={inv.id} className="p-4 space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-num font-bold text-sm text-[#063B2C] dark:text-white">
                        {inv.invoiceNumber}
                      </span>
                      <span className="font-mono-num text-xs text-slate-600 dark:text-emerald-200/75">
                        {inv.date}
                      </span>
                    </div>

                    <div className="text-xs text-[#4B635B] dark:text-emerald-200/80 flex items-center gap-1.5">
                      <span>{t.invoices.fieldTaxType}:</span>
                      <span className="font-semibold text-[#063B2C] dark:text-white">{inv.taxCode}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num">{inv.taxRate}%</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1 text-xs border-t border-[#ECEEE9] dark:border-[#14392E]">
                      <div>
                        <div className="text-[11px] text-[#4B635B] dark:text-emerald-200/70">
                          {t.invoices.colHt}
                        </div>
                        <div className="font-mono-num font-medium text-[#063B2C] dark:text-emerald-100 mt-0.5">
                          {formatDzd(inv.amountHT, lang, currencyDisplay)}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-[#4B635B] dark:text-emerald-200/70">
                          {t.invoices.colTaxAmt}
                        </div>
                        <div className="font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158] mt-0.5">
                          {formatDzd(inv.taxAmount, lang, currencyDisplay)}
                        </div>
                      </div>
                      <div className="text-end">
                        <div className="text-[11px] text-[#4B635B] dark:text-emerald-200/70">
                          {t.invoices.colTtc}
                        </div>
                        <div className="font-mono-num font-bold text-[#063B2C] dark:text-white mt-0.5">
                          {formatDzd(inv.amountTTC, lang, currencyDisplay)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </section>
      )}

      {/* Category Breakdown Table */}
      <section className="bg-white dark:bg-[#0A221B] rounded-xl border border-[#E3E6E0] dark:border-[#163D32] overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E3E6E0] dark:border-[#163D32]">
          <h3 className="text-base font-bold text-[#063B2C] dark:text-white">
            {t.reports.categoryBreakdown}
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E3E6E0] dark:border-[#163D32] bg-[#F1F2EE]/80 dark:bg-[#0E2B22] text-xs text-[#0A4A37] dark:text-emerald-200/80">
                <th className="py-3 px-5 text-start font-semibold">{t.invoices.fieldTaxType}</th>
                <th className="py-3 px-4 text-start font-semibold">{t.reports.colEffectiveRef}</th>
                <th className="py-3 px-4 text-end font-semibold">{t.reports.colCount}</th>
                <th className="py-3 px-4 text-end font-semibold">{t.invoices.colHt}</th>
                <th className="py-3 px-4 text-end font-semibold">{t.invoices.colTaxAmt}</th>
                <th className="py-3 px-5 text-end font-semibold">{t.reports.colShare}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#ECEEE9] dark:divide-[#14392E]">
              {categoryRows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500 dark:text-emerald-200/70">
                    {t.dashboard.noData}
                  </td>
                </tr>
              ) : (
                categoryRows.map((c) => (
                  <tr key={c.code} className="hover:bg-[#FAF9F5] dark:hover:bg-[#0E2B22]/60">
                    <td className="py-3 px-5">
                      <span className="font-semibold text-[#063B2C] dark:text-white">{c.code}</span>
                      <span className="text-slate-400 mx-1.5">·</span>
                      <span className="text-xs text-slate-600 dark:text-emerald-200/80">{c.name}</span>
                    </td>
                    <td className="py-3 px-4 font-mono-num text-xs text-slate-600 dark:text-emerald-200/70">
                      {c.effectiveDate}
                    </td>
                    <td className="py-3 px-4 text-end font-mono-num">{c.count}</td>
                    <td className="py-3 px-4 text-end font-mono-num">
                      {formatDzd(c.ht, lang, currencyDisplay)}
                    </td>
                    <td className="py-3 px-4 text-end font-mono-num font-semibold text-emerald-700 dark:text-[#E5C158]">
                      {formatDzd(c.tax, lang, currencyDisplay)}
                    </td>
                    <td className="py-3 px-5 text-end font-mono-num font-medium">{c.share}%</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      <div className="rounded-xl border border-[#E9D9A6] dark:border-[#524218] bg-[#FBF6E6] dark:bg-[#1E1A0B] p-4 flex items-start gap-3 text-xs text-[#5C440D] dark:text-[#FDE68A]">
        <Info className="w-4 h-4 text-[#B3861D] dark:text-[#E5C158] shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold">
            {t.reports.disclaimerTitle}:{' '}
          </span>
          {t.reports.disclaimerBody}
        </div>
      </div>
    </div>
  );
};
