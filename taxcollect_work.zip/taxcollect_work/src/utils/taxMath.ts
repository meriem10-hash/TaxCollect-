import { CalculationMode, Language } from '../types';

export function roundMoney(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export interface TaxCalculationResult {
  amountHT: number;
  taxAmount: number;
  amountTTC: number;
  netAfterTax: number;
  rate: number;
  mode: CalculationMode;
}

export function calculateTax(
  inputAmount: number,
  ratePercent: number,
  mode: CalculationMode
): TaxCalculationResult {
  const safeAmount = Number.isFinite(inputAmount) && inputAmount >= 0 ? inputAmount : 0;
  const safeRate = Number.isFinite(ratePercent) && ratePercent >= 0 ? ratePercent : 0;
  const r = safeRate / 100;

  if (mode === 'reverse_ttc') {
    const amountTTC = roundMoney(safeAmount);
    const amountHT = roundMoney(amountTTC / (1 + r));
    const taxAmount = roundMoney(amountTTC - amountHT);
    return {
      amountHT,
      taxAmount,
      amountTTC,
      netAfterTax: amountHT,
      rate: safeRate,
      mode,
    };
  }

  if (mode === 'direct_base') {
    const amountHT = roundMoney(safeAmount);
    const taxAmount = roundMoney(amountHT * r);
    const netAfterTax = roundMoney(amountHT - taxAmount);
    const amountTTC = roundMoney(amountHT + taxAmount);
    return {
      amountHT,
      taxAmount,
      amountTTC,
      netAfterTax,
      rate: safeRate,
      mode,
    };
  }

  // Default: forward_ht
  const amountHT = roundMoney(safeAmount);
  const taxAmount = roundMoney(amountHT * r);
  const amountTTC = roundMoney(amountHT + taxAmount);
  return {
    amountHT,
    taxAmount,
    amountTTC,
    netAfterTax: amountHT,
    rate: safeRate,
    mode,
  };
}

export function formatDzd(
  amount: number,
  lang: Language,
  currencyDisplay: 'code' | 'symbol' = 'code'
): string {
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(roundMoney(amount));

  if (currencyDisplay === 'symbol') {
    return lang === 'ar' ? `${formatted} د.ج` : `${formatted} DA`;
  }
  return lang === 'ar' ? `${formatted} د.ج` : `${formatted} DZD`;
}

export function formatMonthLabel(ym: string, lang: Language): string {
  if (!ym || !/^\d{4}-\d{2}$/.test(ym)) return ym;
  const [year, month] = ym.split('-').map(Number);
  const date = new Date(year, month - 1, 1);
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'en-US', {
    year: 'numeric',
    month: 'short',
  }).format(date);
}
