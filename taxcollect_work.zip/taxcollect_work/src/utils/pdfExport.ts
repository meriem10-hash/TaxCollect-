import { jsPDF } from 'jspdf';
import { Invoice, Language, TaxRuleConfig } from '../types';
import { formatDzd, formatMonthLabel, roundMoney } from './taxMath';

export interface PdfExportResult {
  filename: string;
  blobUrl: string;
  blob: Blob;
  sizeBytes: number;
  pageCount: number;
}

interface ReportExportPayload {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  entityName: string;
  entityNif: string;
  periodLabel: string;
  invoices: Invoice[];
  taxRules: TaxRuleConfig[];
  totals: {
    ht: number;
    tax: number;
    ttc: number;
    count: number;
  };
  monthlyRows: Array<{
    month: string;
    count: number;
    ht: number;
    tax: number;
    ttc: number;
  }>;
  categoryRows: Array<{
    code: string;
    name: string;
    effectiveDate: string;
    count: number;
    ht: number;
    tax: number;
    share: number;
  }>;
}

export interface MonthlyReportExportPayload {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  entityName: string;
  entityNif: string;
  month: string; // YYYY-MM
  taxFilter?: string;
  totals: {
    ht: number;
    tax: number;
    ttc: number;
    count: number;
  };
  invoices: Invoice[];
}

export interface AnnualReportExportPayload {
  lang: Language;
  currencyDisplay: 'code' | 'symbol';
  entityName: string;
  entityNif: string;
  year: string; // YYYY
  taxFilter?: string;
  totals: {
    ht: number;
    tax: number;
    ttc: number;
    count: number;
  };
  monthlyRows: Array<{
    month: string;
    count: number;
    ht: number;
    tax: number;
    ttc: number;
  }>;
  categoryRows: Array<{
    code: string;
    name: string;
    effectiveDate: string;
    count: number;
    ht: number;
    tax: number;
    share: number;
  }>;
  invoices: Invoice[];
}

function formatLongMonthYear(ym: string, lang: Language): string {
  if (!ym || !/^\d{4}-\d{2}$/.test(ym)) return ym;
  const [year, month] = ym.split('-').map(Number);
  const date = new Date(year, month - 1, 1);
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'en-US', {
    year: 'numeric',
    month: 'long',
  }).format(date);
}

function fitCanvasText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let trimmed = text;
  while (trimmed.length > 1 && ctx.measureText(`${trimmed}…`).width > maxWidth) {
    trimmed = trimmed.slice(0, -1);
  }
  return `${trimmed}…`;
}

async function ensureFontsReadyIfNeeded(): Promise<void> {
  if (typeof document === 'undefined' || !document.fonts) return;
  if (document.fonts.status === 'loaded') return;
  await Promise.race([
    document.fonts.ready,
    new Promise<void>((resolve) => setTimeout(resolve, 400)),
  ]);
}

const A4_PT_W = 595.28;
const A4_PT_H = 841.89;

class PdfPageComposer {
  readonly width = 1240; // High-DPI A4 portrait canvas width
  readonly height = 1754; // High-DPI A4 portrait canvas height
  readonly margin = 64;
  readonly contentW = 1240 - 128;
  readonly isRtl: boolean;
  readonly fontFamily: string;
  readonly monoFamily = '"JetBrains Mono", monospace';
  readonly alignStart: CanvasTextAlign;
  readonly alignEnd: CanvasTextAlign;
  readonly xStart: number;
  readonly xEnd: number;

  private pdf: jsPDF;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private hasAddedFirstPage = false;
  private pageNum = 1;
  private continuationSubtitle: string;
  y = 0;

  constructor(isRtl: boolean, continuationSubtitle: string) {
    this.isRtl = isRtl;
    this.continuationSubtitle = continuationSubtitle;
    this.fontFamily = isRtl
      ? '"IBM Plex Sans Arabic", "Plus Jakarta Sans", sans-serif'
      : '"Plus Jakarta Sans", sans-serif';
    this.alignStart = isRtl ? 'right' : 'left';
    this.alignEnd = isRtl ? 'left' : 'right';
    this.xStart = isRtl ? this.width - this.margin : this.margin;
    this.xEnd = isRtl ? this.margin : this.width - this.margin;

    this.pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'pt',
      format: 'a4',
      compress: true,
    });

    const { canvas, ctx } = this.createBlankCanvas();
    this.canvas = canvas;
    this.ctx = ctx;
  }

  private createBlankCanvas(): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
    const canvas = document.createElement('canvas');
    canvas.width = this.width;
    canvas.height = this.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Canvas 2D context unavailable');
    }
    ctx.fillStyle = '#FAF9F5';
    ctx.fillRect(0, 0, this.width, this.height);
    ctx.direction = this.isRtl ? 'rtl' : 'ltr';
    return { canvas, ctx };
  }

  private commitCurrentPage(): void {
    this.ctx.save();
    this.ctx.direction = this.isRtl ? 'rtl' : 'ltr';
    this.ctx.fillStyle = '#6B7F78';
    this.ctx.font = `400 13px ${this.fontFamily}`;
    this.ctx.textAlign = this.alignStart;
    this.ctx.fillText('TaxCollect', this.xStart, this.height - 28);
    this.ctx.textAlign = this.alignEnd;
    this.ctx.fillText(
      this.isRtl ? `صفحة ${this.pageNum}` : `Page ${this.pageNum}`,
      this.xEnd,
      this.height - 28
    );
    this.ctx.restore();

    const imgData = this.canvas.toDataURL('image/png');
    if (!imgData || !imgData.startsWith('data:image/png')) {
      throw new Error('Failed to render PDF page image.');
    }
    if (this.hasAddedFirstPage) {
      this.pdf.addPage('a4', 'portrait');
    }
    this.pdf.addImage(imgData, 'PNG', 0, 0, A4_PT_W, A4_PT_H, undefined, 'FAST');
    this.hasAddedFirstPage = true;
  }

  nextPage(): void {
    this.commitCurrentPage();
    this.pageNum += 1;
    const { canvas, ctx } = this.createBlankCanvas();
    this.canvas = canvas;
    this.ctx = ctx;

    ctx.fillStyle = '#052E22';
    ctx.fillRect(0, 0, this.width, 64);
    ctx.fillStyle = '#D4AF37';
    ctx.fillRect(0, 61, this.width, 3);

    ctx.direction = this.isRtl ? 'rtl' : 'ltr';
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `700 18px ${this.fontFamily}`;
    ctx.textAlign = this.alignStart;
    ctx.fillText(`TaxCollect — ${this.continuationSubtitle}`, this.xStart, 40);

    ctx.fillStyle = '#FDE68A';
    ctx.font = `500 14px ${this.fontFamily}`;
    ctx.textAlign = this.alignEnd;
    ctx.fillText(this.isRtl ? `صفحة ${this.pageNum}` : `Page ${this.pageNum}`, this.xEnd, 40);

    this.y = 100;
  }

  ensureSpace(neededHeight: number, onNewPage?: () => void): void {
    if (this.y + neededHeight > this.height - 84) {
      this.nextPage();
      onNewPage?.();
    }
  }

  drawMainHeader(title: string, entityName: string, entityNif: string, periodText: string): void {
    const ctx = this.ctx;
    ctx.fillStyle = '#052E22';
    ctx.fillRect(0, 0, this.width, 150);

    ctx.fillStyle = '#D4AF37';
    ctx.fillRect(0, 144, this.width, 6);

    ctx.direction = this.isRtl ? 'rtl' : 'ltr';

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `700 30px ${this.fontFamily}`;
    ctx.textAlign = this.alignStart;
    ctx.fillText(title, this.xStart, 62);

    ctx.fillStyle = '#CBD5E1';
    ctx.font = `400 17px ${this.fontFamily}`;
    const entityLine = this.isRtl
      ? `الجهة: ${entityName || 'مؤسسة / مشروع محاسبي'}${entityNif ? ` · NIF: ${entityNif}` : ''}`
      : `Entity: ${entityName || 'Accounting Entity'}${entityNif ? ` · NIF: ${entityNif}` : ''}`;
    ctx.fillText(fitCanvasText(ctx, entityLine, this.contentW * 0.62), this.xStart, 102);

    ctx.fillStyle = '#FDE68A';
    ctx.font = `600 17px ${this.fontFamily}`;
    ctx.textAlign = this.alignEnd;
    ctx.fillText(periodText, this.xEnd, 62);

    const dateStr = new Date().toISOString().slice(0, 10);
    ctx.fillStyle = '#CBD5E1';
    ctx.font = `400 15px ${this.fontFamily}`;
    ctx.fillText(
      this.isRtl ? `تاريخ الإصدار: ${dateStr}` : `Generated: ${dateStr}`,
      this.xEnd,
      100
    );

    this.y = 188;
  }

  drawKpiRow(
    kpis: Array<{ label: string; value: string; accent: string; darkCard?: boolean }>
  ): void {
    this.ensureSpace(136);
    const ctx = this.ctx;
    const gap = 18;
    const cardW = (this.contentW - gap * (kpis.length - 1)) / kpis.length;

    kpis.forEach((kpi, idx) => {
      const colIndex = this.isRtl ? kpis.length - 1 - idx : idx;
      const cx = this.margin + colIndex * (cardW + gap);

      if (kpi.darkCard) {
        ctx.fillStyle = '#052E22';
        ctx.strokeStyle = '#D4AF37';
      } else {
        ctx.fillStyle = '#F1F2EE';
        ctx.strokeStyle = '#E0E3DD';
      }
      ctx.lineWidth = 1.5;
      ctx.fillRect(cx, this.y, cardW, 104);
      ctx.strokeRect(cx, this.y, cardW, 104);

      const tx = this.isRtl ? cx + cardW - 18 : cx + 18;
      ctx.direction = this.isRtl ? 'rtl' : 'ltr';
      ctx.textAlign = this.alignStart;
      ctx.fillStyle = kpi.darkCard ? '#D1FAE5' : '#4B635B';
      ctx.font = `500 14px ${this.fontFamily}`;
      ctx.fillText(fitCanvasText(ctx, kpi.label, cardW - 36), tx, this.y + 34);

      ctx.direction = 'ltr';
      ctx.textAlign = this.isRtl ? 'right' : 'left';
      ctx.fillStyle = kpi.darkCard ? '#FDE68A' : kpi.accent;
      ctx.font = `700 21px ${this.monoFamily}`;
      ctx.fillText(fitCanvasText(ctx, kpi.value, cardW - 36), tx, this.y + 74);
    });

    this.y += 140;
  }

  drawTable(
    title: string,
    headers: string[],
    rows: Array<Array<{ text: string; mono?: boolean; bold?: boolean; color?: string; ltr?: boolean }>>,
    colFractions: number[],
    emptyText: string
  ): void {
    const rowHeight = 40;
    const headerHeight = 40;

    const drawHeaderBar = (withTitle: boolean) => {
      const ctx = this.ctx;
      if (withTitle) {
        ctx.direction = this.isRtl ? 'rtl' : 'ltr';
        ctx.textAlign = this.alignStart;
        ctx.fillStyle = '#063B2C';
        ctx.font = `700 20px ${this.fontFamily}`;
        ctx.fillText(title, this.xStart, this.y);
        this.y += 18;
      }

      ctx.fillStyle = '#052E22';
      ctx.fillRect(this.margin, this.y, this.contentW, headerHeight);

      ctx.direction = this.isRtl ? 'rtl' : 'ltr';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `600 14px ${this.fontFamily}`;

      let offset = 0;
      headers.forEach((h, i) => {
        const colW = this.contentW * colFractions[i];
        const cellX = this.isRtl
          ? this.width - this.margin - offset - 14
          : this.margin + offset + 14;
        ctx.textAlign = this.alignStart;
        ctx.fillText(fitCanvasText(ctx, h, colW - 24), cellX, this.y + 25);
        offset += colW;
      });
      this.y += headerHeight;
    };

    this.ensureSpace(120);
    drawHeaderBar(true);

    if (rows.length === 0) {
      const ctx = this.ctx;
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(this.margin, this.y, this.contentW, 50);
      ctx.strokeStyle = '#E0E3DD';
      ctx.strokeRect(this.margin, this.y, this.contentW, 50);
      ctx.direction = this.isRtl ? 'rtl' : 'ltr';
      ctx.fillStyle = '#6B7F78';
      ctx.font = `400 15px ${this.fontFamily}`;
      ctx.textAlign = 'center';
      ctx.fillText(emptyText, this.width / 2, this.y + 31);
      this.y += 78;
      return;
    }

    rows.forEach((row, rIdx) => {
      this.ensureSpace(rowHeight + 16, () => {
        drawHeaderBar(false);
      });

      const ctx = this.ctx;
      ctx.fillStyle = rIdx % 2 === 0 ? '#FFFFFF' : '#F6F7F4';
      ctx.fillRect(this.margin, this.y, this.contentW, rowHeight);
      ctx.strokeStyle = '#E0E3DD';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(this.margin, this.y + rowHeight);
      ctx.lineTo(this.width - this.margin, this.y + rowHeight);
      ctx.stroke();

      let rOffset = 0;
      row.forEach((cell, cIdx) => {
        const colW = this.contentW * colFractions[cIdx];
        const cellX = this.isRtl
          ? this.width - this.margin - rOffset - 14
          : this.margin + rOffset + 14;

        ctx.direction = cell.ltr ? 'ltr' : this.isRtl ? 'rtl' : 'ltr';
        ctx.textAlign = this.isRtl ? 'right' : 'left';
        ctx.fillStyle = cell.color || '#063B2C';
        const weight = cell.bold ? '700' : '500';
        const family = cell.mono ? this.monoFamily : this.fontFamily;
        ctx.font = `${weight} 13.5px ${family}`;
        ctx.fillText(fitCanvasText(ctx, cell.text, colW - 22), cellX, this.y + 25);
        rOffset += colW;
      });
      this.y += rowHeight;
    });

    this.y += 36;
  }

  drawDisclaimerFooter(): void {
    this.ensureSpace(108);
    const ctx = this.ctx;
    const footerY = Math.max(this.y + 4, this.height - 150);

    ctx.fillStyle = '#FBF6E6';
    ctx.strokeStyle = '#E9D9A6';
    ctx.lineWidth = 1.5;
    ctx.fillRect(this.margin, footerY, this.contentW, 84);
    ctx.strokeRect(this.margin, footerY, this.contentW, 84);

    ctx.direction = this.isRtl ? 'rtl' : 'ltr';
    ctx.textAlign = this.alignStart;
    ctx.fillStyle = '#5C440D';
    ctx.font = `700 14px ${this.fontFamily}`;
    ctx.fillText(
      this.isRtl ? 'ملاحظة التحقق القانوني:' : 'Legal Verification Notice:',
      this.xStart + (this.isRtl ? -16 : 16),
      footerY + 28
    );

    ctx.font = `400 13px ${this.fontFamily}`;
    ctx.fillStyle = '#6B4F0E';
    ctx.fillText(
      fitCanvasText(
        ctx,
        this.isRtl
          ? 'تم حساب هذا التقرير بناءً على المعدلات المضبوطة والفواتير المسجلة في TaxCollect. يرجى التحقق من قانون المالية الجزائري الساري قبل التصريح الرسمي.'
          : 'Computed using configured TaxCollect rules and saved invoices. Always verify statutory rates & thresholds against the active Algerian Finance Law.',
        this.contentW - 36
      ),
      this.xStart + (this.isRtl ? -16 : 16),
      footerY + 56
    );
  }

  saveAndDownload(filename: string): PdfExportResult {
    this.commitCurrentPage();
    const arrayBuffer = this.pdf.output('arraybuffer');
    if (!arrayBuffer || arrayBuffer.byteLength < 100) {
      throw new Error('Generated PDF document is empty.');
    }

    const headerBytes = new Uint8Array(arrayBuffer, 0, 5);
    const headerStr = String.fromCharCode(...headerBytes);
    if (headerStr !== '%PDF-') {
      throw new Error('Generated binary output is not a valid PDF.');
    }

    const blob = new Blob([arrayBuffer], { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(blob);

    // Synchronous DOM-attached anchor click preserves transient user gesture on Android & mobile browsers
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    link.type = 'application/pdf';
    link.rel = 'noopener noreferrer';
    link.style.position = 'fixed';
    link.style.left = '-9999px';
    link.style.top = '0';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    return {
      filename,
      blobUrl,
      blob,
      sizeBytes: arrayBuffer.byteLength,
      pageCount: this.pageNum,
    };
  }
}

/**
 * Renders the standard filtered TaxCollect report into a downloadable multi-page A4 PDF.
 */
export async function exportTaxReportPdf(payload: ReportExportPayload): Promise<PdfExportResult> {
  if (document.fonts && document.fonts.status !== 'loaded') {
    await ensureFontsReadyIfNeeded();
  }

  const { lang, currencyDisplay, entityName, entityNif, periodLabel, totals, monthlyRows, categoryRows } =
    payload;
  const isRtl = lang === 'ar';

  const composer = new PdfPageComposer(
    isRtl,
    isRtl ? `التقرير الضريبي (${periodLabel})` : `Tax Report (${periodLabel})`
  );

  composer.drawMainHeader(
    isRtl ? 'TaxCollect — التقرير الضريبي المالي' : 'TaxCollect — Financial & Tax Report',
    entityName,
    entityNif,
    isRtl ? `الفترة: ${periodLabel}` : `Period: ${periodLabel}`
  );

  composer.drawKpiRow([
    {
      label: isRtl ? 'إجمالي المبلغ خارج الرسم (HT)' : 'Total Amount Before Tax (HT)',
      value: formatDzd(totals.ht, lang, currencyDisplay),
      accent: '#063B2C',
    },
    {
      label: isRtl ? 'إجمالي الضرائب المحسوبة' : 'Total Tax Amount',
      value: formatDzd(totals.tax, lang, currencyDisplay),
      accent: '#059669',
      darkCard: true,
    },
    {
      label: isRtl ? 'الإجمالي متضمن الرسوم (TTC)' : 'Total Amount After Tax (TTC)',
      value: formatDzd(totals.ttc, lang, currencyDisplay),
      accent: '#063B2C',
    },
    {
      label: isRtl ? 'عدد الفواتير المشمولة' : 'Total Invoices',
      value: String(totals.count),
      accent: '#B3861D',
    },
  ]);

  composer.drawTable(
    isRtl ? 'الملخص الضريبي الشهري' : 'Monthly Tax Summary',
    isRtl
      ? ['الشهر', 'الفواتير', 'المبلغ HT', 'قيمة الضريبة', 'الإجمالي TTC']
      : ['Month', 'Invoices', 'Before Tax (HT)', 'Tax Amount', 'Total (TTC)'],
    monthlyRows.map((m) => [
      { text: formatMonthLabel(m.month, lang), bold: true },
      { text: String(m.count), mono: true, ltr: true },
      { text: formatDzd(m.ht, lang, currencyDisplay), mono: true, ltr: !isRtl },
      { text: formatDzd(m.tax, lang, currencyDisplay), mono: true, bold: true, color: '#059669', ltr: !isRtl },
      { text: formatDzd(m.ttc, lang, currencyDisplay), mono: true, bold: true, ltr: !isRtl },
    ]),
    [0.24, 0.12, 0.22, 0.2, 0.22],
    isRtl ? 'لا توجد بيانات لهذه الفترة' : 'No records for this period'
  );

  composer.drawTable(
    isRtl ? 'التوزيع حسب نوع الضريبة' : 'Tax Breakdown by Category',
    isRtl
      ? ['الضريبة', 'تاريخ السريان', 'الفواتير', 'الأساس HT', 'الضريبة المستحقة']
      : ['Tax Category', 'Effective Date', 'Invoices', 'Before Tax (HT)', 'Tax Due'],
    categoryRows.map((c) => [
      { text: `${c.code} · ${roundMoney(c.share)}%`, bold: true, ltr: true },
      { text: c.effectiveDate, mono: true, ltr: true },
      { text: String(c.count), mono: true, ltr: true },
      { text: formatDzd(c.ht, lang, currencyDisplay), mono: true, ltr: !isRtl },
      { text: formatDzd(c.tax, lang, currencyDisplay), mono: true, bold: true, color: '#059669', ltr: !isRtl },
    ]),
    [0.26, 0.18, 0.12, 0.22, 0.22],
    isRtl ? 'لا توجد بيانات لهذه الفترة' : 'No records for this period'
  );

  composer.drawDisclaimerFooter();
  const dateStr = new Date().toISOString().slice(0, 10);
  return composer.saveAndDownload(`TaxCollect_Report_${dateStr}.pdf`);
}

/**
 * Exports a detailed Monthly Report PDF with TaxCollect branding, selected month & year,
 * summary KPIs, and an itemized table of every invoice belonging to that month.
 */
export async function exportMonthlyReportPdf(
  payload: MonthlyReportExportPayload
): Promise<PdfExportResult> {
  if (document.fonts && document.fonts.status !== 'loaded') {
    await ensureFontsReadyIfNeeded();
  }

  const { lang, currencyDisplay, entityName, entityNif, month, taxFilter, totals, invoices } = payload;
  const isRtl = lang === 'ar';
  const monthYearLabel = formatLongMonthYear(month, lang);

  const periodSuffix =
    taxFilter && taxFilter !== 'ALL'
      ? `${monthYearLabel} · ${taxFilter}`
      : monthYearLabel;

  const composer = new PdfPageComposer(
    isRtl,
    isRtl ? `التقرير الشهري — ${periodSuffix}` : `Monthly Report — ${periodSuffix}`
  );

  composer.drawMainHeader(
    isRtl ? 'TaxCollect — التقرير الضريبي الشهري' : 'TaxCollect — Monthly Tax Report',
    entityName,
    entityNif,
    isRtl ? `الشهر والسنة: ${periodSuffix}` : `Month & Year: ${periodSuffix}`
  );

  composer.drawKpiRow([
    {
      label: isRtl ? 'إجمالي عدد الفواتير' : 'Total Invoices',
      value: String(totals.count),
      accent: '#B3861D',
    },
    {
      label: isRtl ? 'الإجمالي قبل الضريبة (HT)' : 'Total Before Tax (HT)',
      value: formatDzd(totals.ht, lang, currencyDisplay),
      accent: '#063B2C',
    },
    {
      label: isRtl ? 'إجمالي قيمة الضريبة' : 'Total Tax Amount',
      value: formatDzd(totals.tax, lang, currencyDisplay),
      accent: '#059669',
      darkCard: true,
    },
    {
      label: isRtl ? 'الإجمالي بعد الضريبة (TTC)' : 'Total After Tax (TTC)',
      value: formatDzd(totals.ttc, lang, currencyDisplay),
      accent: '#063B2C',
    },
  ]);

  composer.drawTable(
    isRtl ? `تفاصيل فواتير شهر ${monthYearLabel}` : `Detailed Invoices — ${monthYearLabel}`,
    isRtl
      ? ['رقم الفاتورة', 'التاريخ', 'نوع الضريبة', 'المبلغ قبل الضريبة', 'قيمة الضريبة', 'المبلغ الإجمالي']
      : ['Invoice #', 'Date', 'Tax Type', 'Before Tax (HT)', 'Tax Amount', 'Total (TTC)'],
    invoices.map((inv) => [
      { text: inv.invoiceNumber, mono: true, bold: true, ltr: true },
      { text: inv.date, mono: true, ltr: true },
      { text: `${inv.taxCode} · ${inv.taxRate}%`, mono: true, ltr: true },
      { text: formatDzd(inv.amountHT, lang, currencyDisplay), mono: true, ltr: !isRtl },
      {
        text: formatDzd(inv.taxAmount, lang, currencyDisplay),
        mono: true,
        bold: true,
        color: '#059669',
        ltr: !isRtl,
      },
      { text: formatDzd(inv.amountTTC, lang, currencyDisplay), mono: true, bold: true, ltr: !isRtl },
    ]),
    [0.17, 0.13, 0.14, 0.19, 0.18, 0.19],
    isRtl ? 'لا توجد فواتير مسجلة لهذا الشهر' : 'No invoices recorded for this month'
  );

  composer.drawDisclaimerFooter();
  return composer.saveAndDownload(`TaxCollect_Monthly_Report_${month}.pdf`);
}

/**
 * Exports a complete Annual Report PDF covering the selected year's KPIs, monthly summary,
 * tax category distribution, and every invoice recorded in that year.
 */
export async function exportAnnualReportPdf(
  payload: AnnualReportExportPayload
): Promise<PdfExportResult> {
  if (document.fonts && document.fonts.status !== 'loaded') {
    await ensureFontsReadyIfNeeded();
  }

  const {
    lang,
    currencyDisplay,
    entityName,
    entityNif,
    year,
    taxFilter,
    totals,
    monthlyRows,
    categoryRows,
    invoices,
  } = payload;
  const isRtl = lang === 'ar';

  const yearDisplay =
    taxFilter && taxFilter !== 'ALL' ? `${year} · ${taxFilter}` : year;

  const composer = new PdfPageComposer(
    isRtl,
    isRtl ? `التقرير السنوي — ${yearDisplay}` : `Annual Report — ${yearDisplay}`
  );

  composer.drawMainHeader(
    isRtl ? 'TaxCollect — التقرير الضريبي السنوي' : 'TaxCollect — Annual Tax Report',
    entityName,
    entityNif,
    isRtl ? `السنة المالية: ${yearDisplay}` : `Fiscal Year: ${yearDisplay}`
  );

  composer.drawKpiRow([
    {
      label: isRtl ? 'إجمالي عدد الفواتير' : 'Total Invoices',
      value: String(totals.count),
      accent: '#B3861D',
    },
    {
      label: isRtl ? 'الإجمالي قبل الضريبة (HT)' : 'Total Before Tax (HT)',
      value: formatDzd(totals.ht, lang, currencyDisplay),
      accent: '#063B2C',
    },
    {
      label: isRtl ? 'إجمالي قيمة الضريبة' : 'Total Tax Amount',
      value: formatDzd(totals.tax, lang, currencyDisplay),
      accent: '#059669',
      darkCard: true,
    },
    {
      label: isRtl ? 'الإجمالي بعد الضريبة (TTC)' : 'Total After Tax (TTC)',
      value: formatDzd(totals.ttc, lang, currencyDisplay),
      accent: '#063B2C',
    },
  ]);

  composer.drawTable(
    isRtl ? `الملخص الشهري لسنة ${year}` : `Monthly Summary — ${year}`,
    isRtl
      ? ['الشهر', 'الفواتير', 'المبلغ HT', 'قيمة الضريبة', 'الإجمالي TTC']
      : ['Month', 'Invoices', 'Before Tax (HT)', 'Tax Amount', 'Total (TTC)'],
    monthlyRows.map((m) => [
      { text: formatMonthLabel(m.month, lang), bold: true },
      { text: String(m.count), mono: true, ltr: true },
      { text: formatDzd(m.ht, lang, currencyDisplay), mono: true, ltr: !isRtl },
      {
        text: formatDzd(m.tax, lang, currencyDisplay),
        mono: true,
        bold: true,
        color: '#059669',
        ltr: !isRtl,
      },
      { text: formatDzd(m.ttc, lang, currencyDisplay), mono: true, bold: true, ltr: !isRtl },
    ]),
    [0.24, 0.12, 0.22, 0.2, 0.22],
    isRtl ? 'لا توجد بيانات شهرية لهذه السنة' : 'No monthly data for this year'
  );

  composer.drawTable(
    isRtl ? `التوزيع حسب نوع الضريبة (${year})` : `Tax Breakdown by Category (${year})`,
    isRtl
      ? ['الضريبة', 'تاريخ السريان', 'الفواتير', 'الأساس HT', 'الضريبة المستحقة']
      : ['Tax Category', 'Effective Date', 'Invoices', 'Before Tax (HT)', 'Tax Due'],
    categoryRows.map((c) => [
      { text: `${c.code} · ${roundMoney(c.share)}%`, bold: true, ltr: true },
      { text: c.effectiveDate, mono: true, ltr: true },
      { text: String(c.count), mono: true, ltr: true },
      { text: formatDzd(c.ht, lang, currencyDisplay), mono: true, ltr: !isRtl },
      {
        text: formatDzd(c.tax, lang, currencyDisplay),
        mono: true,
        bold: true,
        color: '#059669',
        ltr: !isRtl,
      },
    ]),
    [0.26, 0.18, 0.12, 0.22, 0.22],
    isRtl ? 'لا توجد بيانات لهذه السنة' : 'No category data for this year'
  );

  composer.drawTable(
    isRtl ? `سجل فواتير سنة ${year}` : `Annual Invoice Ledger — ${year}`,
    isRtl
      ? ['رقم الفاتورة', 'التاريخ', 'نوع الضريبة', 'المبلغ قبل الضريبة', 'قيمة الضريبة', 'المبلغ الإجمالي']
      : ['Invoice #', 'Date', 'Tax Type', 'Before Tax (HT)', 'Tax Amount', 'Total (TTC)'],
    invoices.map((inv) => [
      { text: inv.invoiceNumber, mono: true, bold: true, ltr: true },
      { text: inv.date, mono: true, ltr: true },
      { text: `${inv.taxCode} · ${inv.taxRate}%`, mono: true, ltr: true },
      { text: formatDzd(inv.amountHT, lang, currencyDisplay), mono: true, ltr: !isRtl },
      {
        text: formatDzd(inv.taxAmount, lang, currencyDisplay),
        mono: true,
        bold: true,
        color: '#059669',
        ltr: !isRtl,
      },
      { text: formatDzd(inv.amountTTC, lang, currencyDisplay), mono: true, bold: true, ltr: !isRtl },
    ]),
    [0.17, 0.13, 0.14, 0.19, 0.18, 0.19],
    isRtl ? 'لا توجد فواتير مسجلة لهذه السنة' : 'No invoices recorded for this year'
  );

  composer.drawDisclaimerFooter();
  return composer.saveAndDownload(`TaxCollect_Annual_Report_${year}.pdf`);
}

export function exportInvoicesCsv(invoices: Invoice[]): void {
  const headers = [
    'Invoice Number',
    'Client Name',
    'NIF',
    'Date',
    'Tax Code',
    'Tax Rate (%)',
    'Amount HT (DZD)',
    'Tax Amount (DZD)',
    'Amount TTC (DZD)',
    'Status',
    'Description',
  ];

  const escapeCsv = (val: string | number | undefined) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const rows = invoices.map((inv) =>
    [
      inv.invoiceNumber,
      inv.clientName,
      inv.clientNif || '',
      inv.date,
      inv.taxCode,
      inv.taxRate,
      roundMoney(inv.amountHT).toFixed(2),
      roundMoney(inv.taxAmount).toFixed(2),
      roundMoney(inv.amountTTC).toFixed(2),
      inv.status,
      inv.description,
    ]
      .map(escapeCsv)
      .join(',')
  );

  const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `TaxCollect_Invoices_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
