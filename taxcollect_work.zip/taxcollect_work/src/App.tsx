import { useEffect, useState } from 'react';
import { DEFAULT_TAX_RULES } from './data/taxRules';
import { SEED_INVOICES } from './data/seedInvoices';
import {
  CalculatorSnapshot,
  Invoice,
  NavView,
  TaxRuleConfig,
  UserPreferences,
} from './types';
import { Layout } from './components/Layout';
import { DashboardView } from './components/DashboardView';
import { CalculatorView } from './components/CalculatorView';
import { InvoicesView } from './components/InvoicesView';
import { ReportsView } from './components/ReportsView';
import { AssistantView } from './components/AssistantView';
import { LibraryView } from './components/LibraryView';
import { SettingsView } from './components/SettingsView';

const STORAGE_KEYS = {
  invoices: 'taxcollect_invoices_v1',
  rules: 'taxcollect_tax_rules_v1',
  prefs: 'taxcollect_preferences_v1',
};

const DEFAULT_PREFERENCES: UserPreferences = {
  language: 'en',
  theme: 'light',
  entityName: 'Cabinet Comptable & Conseil Alger',
  entityNif: '001616098451234',
  showLegalNotices: true,
  currencyDisplay: 'code',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [activeView, setActiveView] = useState<NavView>('dashboard');
  const [preferences, setPreferences] = useState<UserPreferences>(() =>
    loadFromStorage<UserPreferences>(STORAGE_KEYS.prefs, DEFAULT_PREFERENCES)
  );
  const [taxRules, setTaxRules] = useState<TaxRuleConfig[]>(() =>
    loadFromStorage<TaxRuleConfig[]>(STORAGE_KEYS.rules, DEFAULT_TAX_RULES)
  );
  const [invoices, setInvoices] = useState<Invoice[]>(() =>
    loadFromStorage<Invoice[]>(STORAGE_KEYS.invoices, SEED_INVOICES)
  );

  // Cross-view workflow state
  const [calcInitialRuleId, setCalcInitialRuleId] = useState<string | null>(null);
  const [aiAttachedContext, setAiAttachedContext] = useState<CalculatorSnapshot | null>(null);
  const [externalInvoiceModalOpen, setExternalInvoiceModalOpen] = useState(false);
  const [invoicePrefill, setInvoicePrefill] = useState<Partial<
    Omit<Invoice, 'id' | 'createdAt'>
  > | null>(null);

  // Sync HTML direction, language, and dark theme class
  useEffect(() => {
    const root = document.documentElement;
    root.lang = preferences.language;
    root.dir = preferences.language === 'ar' ? 'rtl' : 'ltr';
    if (preferences.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(STORAGE_KEYS.prefs, JSON.stringify(preferences));
    } catch {
      // Ignore storage quota issues
    }
  }, [preferences]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.rules, JSON.stringify(taxRules));
    } catch {
      // Ignore storage quota issues
    }
  }, [taxRules]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.invoices, JSON.stringify(invoices));
    } catch {
      // Ignore storage quota issues
    }
  }, [invoices]);

  const handleUpdatePreferences = (patch: Partial<UserPreferences>) => {
    setPreferences((prev) => ({ ...prev, ...patch }));
  };

  const handleToggleLanguage = () => {
    handleUpdatePreferences({
      language: preferences.language === 'en' ? 'ar' : 'en',
    });
  };

  const handleToggleTheme = () => {
    handleUpdatePreferences({
      theme: preferences.theme === 'light' ? 'dark' : 'light',
    });
  };

  const handleAddInvoice = (data: Omit<Invoice, 'id' | 'createdAt'>) => {
    const newInvoice: Invoice = {
      ...data,
      id: `inv-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setInvoices((prev) => [newInvoice, ...prev]);
  };

  const handleUpdateInvoice = (updated: Invoice) => {
    setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
  };

  const handleDeleteInvoice = (id: string) => {
    setInvoices((prev) => prev.filter((inv) => inv.id !== id));
  };

  const handleUpdateTaxRule = (ruleId: string, patch: Partial<TaxRuleConfig>) => {
    setTaxRules((prev) =>
      prev.map((rule) => (rule.id === ruleId ? { ...rule, ...patch } : rule))
    );
  };

  const handleOpenNewInvoiceModal = (
    prefill?: Partial<Omit<Invoice, 'id' | 'createdAt'>> | null
  ) => {
    setInvoicePrefill(prefill ?? null);
    setExternalInvoiceModalOpen(true);
    setActiveView('invoices');
  };

  const handleSaveCalcAsInvoice = (snapshot: CalculatorSnapshot) => {
    handleOpenNewInvoiceModal({
      taxRuleId: snapshot.taxRuleId,
      taxCode: snapshot.taxCode,
      taxRate: snapshot.rate,
      amountHT: snapshot.amountHT,
      date: snapshot.transactionDate,
      description: `${snapshot.taxCode} (${snapshot.rate}%) calculation`,
      status: 'pending',
    });
  };

  const handleAskAiFromCalc = (snapshot: CalculatorSnapshot) => {
    setAiAttachedContext(snapshot);
    setActiveView('assistant');
  };

  const handleOpenRuleInCalculator = (ruleId: string) => {
    setCalcInitialRuleId(ruleId);
    setActiveView('calculator');
  };

  return (
    <Layout
      lang={preferences.language}
      theme={preferences.theme}
      activeView={activeView}
      onSelectView={setActiveView}
      onToggleLanguage={handleToggleLanguage}
      onToggleTheme={handleToggleTheme}
      onNewInvoice={() => handleOpenNewInvoiceModal(null)}
    >
      {activeView === 'dashboard' && (
        <DashboardView
          lang={preferences.language}
          currencyDisplay={preferences.currencyDisplay}
          invoices={invoices}
          taxRules={taxRules}
          onNavigate={setActiveView}
          onNewInvoice={() => handleOpenNewInvoiceModal(null)}
        />
      )}

      {activeView === 'calculator' && (
        <CalculatorView
          lang={preferences.language}
          currencyDisplay={preferences.currencyDisplay}
          taxRules={taxRules}
          initialRuleId={calcInitialRuleId}
          showLegalNotices={preferences.showLegalNotices}
          onSaveAsInvoice={handleSaveCalcAsInvoice}
          onAskAi={handleAskAiFromCalc}
        />
      )}

      {activeView === 'invoices' && (
        <InvoicesView
          lang={preferences.language}
          currencyDisplay={preferences.currencyDisplay}
          invoices={invoices}
          taxRules={taxRules}
          onAddInvoice={handleAddInvoice}
          onUpdateInvoice={handleUpdateInvoice}
          onDeleteInvoice={handleDeleteInvoice}
          prefillModalOpen={externalInvoiceModalOpen}
          prefillData={invoicePrefill}
          onCloseExternalModal={() => {
            setExternalInvoiceModalOpen(false);
            setInvoicePrefill(null);
          }}
        />
      )}

      {activeView === 'reports' && (
        <ReportsView
          lang={preferences.language}
          currencyDisplay={preferences.currencyDisplay}
          entityName={preferences.entityName}
          entityNif={preferences.entityNif}
          invoices={invoices}
          taxRules={taxRules}
        />
      )}

      {activeView === 'assistant' && (
        <AssistantView
          lang={preferences.language}
          currencyDisplay={preferences.currencyDisplay}
          attachedContext={aiAttachedContext}
          onClearContext={() => setAiAttachedContext(null)}
        />
      )}

      {activeView === 'library' && (
        <LibraryView
          lang={preferences.language}
          taxRules={taxRules}
          onOpenInCalculator={handleOpenRuleInCalculator}
        />
      )}

      {activeView === 'settings' && (
        <SettingsView
          preferences={preferences}
          taxRules={taxRules}
          invoices={invoices}
          onUpdatePreferences={handleUpdatePreferences}
          onUpdateTaxRule={handleUpdateTaxRule}
          onRestoreDefaultRules={() => setTaxRules(DEFAULT_TAX_RULES)}
          onResetSampleInvoices={() => setInvoices(SEED_INVOICES)}
          onClearAllInvoices={() => setInvoices([])}
        />
      )}
    </Layout>
  );
}
