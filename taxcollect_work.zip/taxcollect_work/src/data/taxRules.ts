import { TaxRuleConfig } from '../types';

export interface TaxLibraryArticle {
  ruleId: string;
  categoryEn: string;
  categoryAr: string;
  summaryEn: string;
  summaryAr: string;
  scopeEn: string;
  scopeAr: string;
  formulaEn: string;
  formulaAr: string;
  exampleTitleEn: string;
  exampleTitleAr: string;
  exampleStepsEn: string[];
  exampleStepsAr: string[];
  keyNotesEn: string[];
  keyNotesAr: string[];
}

export const DEFAULT_TAX_RULES: TaxRuleConfig[] = [
  {
    id: 'tva-standard',
    code: 'TVA',
    acronym: 'TVA',
    nameEn: 'Value Added Tax (TVA)',
    nameAr: 'الرسم على القيمة المضافة (TVA)',
    defaultRate: 19,
    rateOptions: [
      { id: 'tva-19', rate: 19, labelEn: '19% — Standard Rate', labelAr: '19% — المعدل العادي' },
      { id: 'tva-9', rate: 9, labelEn: '9% — Reduced Rate', labelAr: '9% — المعدل المخفض' },
      { id: 'tva-0', rate: 0, labelEn: '0% — Exempt / Export', labelAr: '0% — معفى / تصدير' },
    ],
    effectiveDate: '2017-01-01',
    legalReferenceEn: 'Code des Taxes sur le Chiffre d’Affaires (CTCA) · Verify latest Finance Law',
    legalReferenceAr: 'قانون الرسوم على رقم الأعمال · يرجى التحقق من آخر قانون مالية',
    requiresVerification: true,
    verificationNoteEn:
      'Rates (19% standard / 9% reduced) depend on goods/services classification and exemptions under the current Algerian Finance Law.',
    verificationNoteAr:
      'تعتمد المعدلات (19% عادي / 9% مخفض) على تصنيف السلع والخدمات والإعفاءات في قانون المالية الجزائري الساري.',
    calculationNature: 'indirect_vat',
  },
  {
    id: 'ibs-corporate',
    code: 'IBS',
    acronym: 'IBS',
    nameEn: 'Corporate Income Tax (IBS)',
    nameAr: 'الضريبة على أرباح الشركات (IBS)',
    defaultRate: 26,
    rateOptions: [
      { id: 'ibs-19', rate: 19, labelEn: '19% — Production of Goods', labelAr: '19% — نشاط إنتاج السلع' },
      { id: 'ibs-23', rate: 23, labelEn: '23% — Construction, Public Works & Tourism', labelAr: '23% — البناء والأشغال والسياحة' },
      { id: 'ibs-26', rate: 26, labelEn: '26% — Trade & Services', labelAr: '26% — التجارة والخدمات' },
    ],
    effectiveDate: '2022-01-01',
    legalReferenceEn: 'Code des Impôts Directs et Taxes Assimilées (CIDTA) · Art. 150',
    legalReferenceAr: 'قانون الضرائب المباشرة والرسوم المماثلة · المادة 150',
    requiresVerification: true,
    verificationNoteEn:
      'IBS applies to net taxable fiscal profit. Specific sectoral rates, reinvested profit reductions, and minimum tax (10,000 DZD) must be verified with the current Finance Law.',
    verificationNoteAr:
      'تطبق الضريبة على الربح الجبائي الصافي. يجب التحقق من المعدلات القطاعية وتخفيضات إعادة الاستثمار والحد الأدنى للضريبة وفق قانون المالية الساري.',
    calculationNature: 'direct_profit_income',
  },
  {
    id: 'irg-income',
    code: 'IRG',
    acronym: 'IRG',
    nameEn: 'Global Income Tax (IRG)',
    nameAr: 'الضريبة على الدخل الإجمالي (IRG)',
    defaultRate: 15,
    rateOptions: [
      { id: 'irg-10', rate: 10, labelEn: '10% — Reference Withholding / Dividends (Verify)', labelAr: '10% — اقتطاع مرجعي / أرباح الأسهم (يتطلب تحققاً)' },
      { id: 'irg-15', rate: 15, labelEn: '15% — Configurable Reference Rate', labelAr: '15% — معدل مرجعي قابل للتعديل' },
      { id: 'irg-23', rate: 23, labelEn: '23% — Progressive Bracket Example', labelAr: '23% — مثال شريحة تصاعدية' },
      { id: 'irg-30', rate: 30, labelEn: '30% — Progressive Bracket Example', labelAr: '30% — مثال شريحة تصاعدية' },
    ],
    effectiveDate: '2022-01-01',
    legalReferenceEn: 'CIDTA Progressive Scale & Withholding Rules · Verify official IRG Bareme',
    legalReferenceAr: 'الجدول التصاعدي للضريبة على الدخل الإجمالي · يرجى مراجعة سلم IRG الرسمي',
    requiresVerification: true,
    verificationNoteEn:
      'IRG salaries and non-commercial income follow official progressive brackets (barème IRG) with abatements and exemptions (e.g., threshold rules). Always configure the exact effective rate or bracket.',
    verificationNoteAr:
      'يخضع الدخل الإجمالي للأجور والمهن غير التجارية لسلم تصاعدي رسمي وتخفيضات وإعفاءات. يرجى دائماً ضبط المعدل أو الشريحة الفعلية والتحقق من سلم الضرائب الرسمي.',
    calculationNature: 'direct_profit_income',
  },
  {
    id: 'ifu-flat',
    code: 'IFU',
    acronym: 'IFU',
    nameEn: 'Single Flat Tax (IFU)',
    nameAr: 'الضريبة الجزافية الوحيدة (IFU)',
    defaultRate: 5,
    rateOptions: [
      { id: 'ifu-5', rate: 5, labelEn: '5% — Production & Sale of Goods', labelAr: '5% — نشاط الإنتاج وبيع السلع' },
      { id: 'ifu-12', rate: 12, labelEn: '12% — Other Activities / Services', labelAr: '12% — النشاطات الأخرى والخدمات' },
      { id: 'ifu-05', rate: 0.5, labelEn: '0.5% — Auto-Entrepreneur Reference (Verify)', labelAr: '0.5% — مرجع المقاول الذاتي (يتطلب تحققاً)' },
    ],
    effectiveDate: '2024-01-01',
    legalReferenceEn: 'CIDTA IFU Regime · Eligibility turnover ceiling & minimum tax apply',
    legalReferenceAr: 'نظام الضريبة الجزافية الوحيدة · تطبق شروط سقف رقم الأعمال والحد الأدنى',
    requiresVerification: true,
    verificationNoteEn:
      'IFU eligibility depends on annual turnover thresholds, excluded activities, and statutory minimum tax (minimum d’imposition). Verify current Finance Law limits.',
    verificationNoteAr:
      'تعتمد أهلية الضريبة الجزافية الوحيدة على سقف رقم الأعمال السنوي والنشاطات المستثناة والحد الأدنى للضريبة. يرجى التحقق من حدود قانون المالية الساري.',
    calculationNature: 'flat_turnover',
  },
  {
    id: 'tap-reference',
    code: 'TAP',
    acronym: 'TAP',
    nameEn: 'Professional Activity Tax (TAP Reference)',
    nameAr: 'الرسم على النشاط المهني (مرجع TAP)',
    defaultRate: 0,
    rateOptions: [
      { id: 'tap-0', rate: 0, labelEn: '0% — Repealed in Finance Law 2024 (Verify)', labelAr: '0% — ملغى بموجب قانون المالية 2024 (تحقق)' },
      { id: 'tap-1.5', rate: 1.5, labelEn: '1.5% — Historical Pre-2024 Rate', labelAr: '1.5% — معدل تاريخي قبل 2024' },
      { id: 'tap-2', rate: 2, labelEn: '2% — Historical Standard Rate', labelAr: '2% — معدل تاريخي عادي' },
    ],
    effectiveDate: '2024-01-01',
    legalReferenceEn: 'Finance Law 2024 Reform Context · Historical / Audit Comparison',
    legalReferenceAr: 'سياق إصلاح قانون المالية 2024 · للمقارنة التاريخية والمراجعة',
    requiresVerification: true,
    verificationNoteEn:
      'Important: TAP was suppressed under the 2024 Finance Law (with specific transitional/sectoral local tax rules such as TLS replacing parts of local taxation). Use 0% for current standard invoices unless auditing pre-2024 records.',
    verificationNoteAr:
      'تنبيه هام: تم إلغاء الرسم على النشاط المهني (TAP) في قانون المالية 2024 (مع استبدال أجزاء من الجباية المحلية برسوم أخرى كـ TLS). استخدم 0% للفواتير الحالية ما لم تكن تراجع سجلات قبل 2024.',
    calculationNature: 'flat_turnover',
  },
  {
    id: 'custom-tax',
    code: 'CUSTOM',
    acronym: 'CUSTOM',
    nameEn: 'Custom Configurable Tax / Fee',
    nameAr: 'ضريبة أو رسم مخصص قابل للتعديل',
    defaultRate: 1,
    rateOptions: [
      { id: 'custom-1', rate: 1, labelEn: '1% — Stamp / Custom Reference', labelAr: '1% — طابع / معدل مخصص' },
      { id: 'custom-5', rate: 5, labelEn: '5% — Custom Rate', labelAr: '5% — معدل مخصص' },
      { id: 'custom-10', rate: 10, labelEn: '10% — Custom Rate', labelAr: '10% — معدل مخصص' },
    ],
    effectiveDate: '2026-01-01',
    legalReferenceEn: 'User-Defined Rule · Verify statutory applicability',
    legalReferenceAr: 'قاعدة محددة من المستخدم · يرجى التحقق من السند القانوني',
    requiresVerification: true,
    verificationNoteEn:
      'Use this rule to model local taxes, stamp duties (Droits de Timbre), or specific sectoral rates tailored to your accounting scenario.',
    verificationNoteAr:
      'استخدم هذه القاعدة لنمذجة الرسوم المحلية أو طابع الدمغة أو المعدلات القطاعية الخاصة بحالتك المحاسبية.',
    calculationNature: 'stamp',
  },
];

export const TAX_LIBRARY_ARTICLES: TaxLibraryArticle[] = [
  {
    ruleId: 'tva-standard',
    categoryEn: 'Indirect Consumption Tax',
    categoryAr: 'ضريبة غير مباشرة على الاستهلاك',
    summaryEn:
      'TVA (Taxe sur la Valeur Ajoutée) is an indirect tax borne by the final consumer and collected across each stage of production and distribution. Businesses collect TVA on sales (TVA collectée) and deduct TVA paid on eligible purchases (TVA déductible), remitting the difference via the monthly G50 return.',
    summaryAr:
      'الرسم على القيمة المضافة (TVA) هو ضريبة غير مباشرة يتحملها المستهلك النهائي وتُحصّل في كل مرحلة من مراحل الإنتاج والتوزيع. تقوم المؤسسة بتحصيل الرسم على المبيعات (TVA محصلة) وتخصم الرسم المدفوع على المشتريات القابلة للاسترجاع (TVA قابلة للاسترجاع) وتدفع الفارق عبر التصريح الشهري G50.',
    scopeEn:
      'Applies to industrial, commercial, handicraft operations, liberal professions, and imports unless specifically exempted by the Code des Taxes sur le Chiffre d’Affaires (CTCA).',
    scopeAr:
      'يطبق على العمليات الصناعية والتجارية والحرفية والمهن الحرة والواردات ما لم تنص أحكام قانون الرسوم على رقم الأعمال على إعفائها.',
    formulaEn: 'Tax = HT × (Rate / 100)  |  TTC = HT + Tax  |  HT = TTC ÷ (1 + Rate / 100)',
    formulaAr: 'قيمة الرسم = المبلغ خارج الرسم × (المعدل ÷ 100)  |  المبلغ متضمن الرسم = خارج الرسم + الرسم',
    exampleTitleEn: 'Invoice Sale Example (19% Standard Rate)',
    exampleTitleAr: 'مثال فاتورة بيع (بالمعدل العادي 19%)',
    exampleStepsEn: [
      'Taxable amount before tax (HT) = 100,000.00 DZD',
      'TVA Amount (19%) = 100,000 × 0.19 = 19,000.00 DZD',
      'Total Invoice Including Tax (TTC) = 100,000 + 19,000 = 119,000.00 DZD',
    ],
    exampleStepsAr: [
      'المبلغ القابل للضريبة خارج الرسم (HT) = 100,000.00 د.ج',
      'قيمة الرسم على القيمة المضافة (19%) = 100,000 × 0.19 = 19,000.00 د.ج',
      'إجمالي الفاتورة متضمن كل الرسوم (TTC) = 100,000 + 19,000 = 119,000.00 د.ج',
    ],
    keyNotesEn: [
      'Monthly declaration is typically submitted via Form G50 by the 20th of the following month (verify exact calendar deadlines).',
      'Always verify whether the good or service qualifies for the 9% reduced rate or statutory exemption under the active Finance Law.',
    ],
    keyNotesAr: [
      'يتم التصريح الشهري عادة عبر استمارة G50 قبل يوم 20 من الشهر الموالي (يرجى التحقق من المواعيد الرسمية).',
      'تحقق دائماً مما إذا كانت السلعة أو الخدمة تخضع للمعدل المخفض 9% أو الإعفاء القانوني بموجب قانون المالية الساري.',
    ],
  },
  {
    ruleId: 'ibs-corporate',
    categoryEn: 'Direct Corporate Profit Tax',
    categoryAr: 'ضريبة مباشرة على أرباح الشركات',
    summaryEn:
      'IBS (Impôt sur les Bénéfices des Sociétés) is an annual direct tax levied on the net fiscal profit realized in Algeria by capital companies (SPA, SARL, EURL, etc.) and assimilated legal entities.',
    summaryAr:
      'الضريبة على أرباح الشركات (IBS) هي ضريبة سنوية مباشرة تُفرض على الربح الجبائي الصافي المحقق في الجزائر من طرف شركات الأموال (SPA, SARL, EURL) والكيانات القانونية المماثلة.',
    scopeEn:
      'Fiscal profit equals Accounting Profit plus non-deductible expenses (reintegrations) minus non-taxable revenues (deductions). Rate depends on the main activity sector.',
    scopeAr:
      'الربح الجبائي يساوي الربح المحاسبي مضافاً إليه الأعباء غير القابلة للخصم (الاستردادات) مطروحاً منه الإيرادات غير الخاضعة للضريبة (التخفيضات). ويختلف المعدل حسب طبيعة النشاط.',
    formulaEn: 'IBS Due = Net Fiscal Profit × Applicable Sector Rate (19%, 23%, or 26%)',
    formulaAr: 'الضريبة المستحقة = الربح الجبائي الصافي × المعدل القطاعي المطبق (19% أو 23% أو 26%)',
    exampleTitleEn: 'Trading Company Profit Example (26% Rate)',
    exampleTitleAr: 'مثال شركة تجارية (بمعدل 26%)',
    exampleStepsEn: [
      'Net Fiscal Profit = 2,500,000.00 DZD',
      'IBS Rate for Trade & Services = 26%',
      'Calculated IBS = 2,500,000 × 0.26 = 650,000.00 DZD',
      'Net Profit After IBS = 1,850,000.00 DZD',
    ],
    exampleStepsAr: [
      'الربح الجبائي الصافي = 2,500,000.00 د.ج',
      'معدل الضريبة لنشاط التجارة والخدمات = 26%',
      'الضريبة المحسوبة (IBS) = 2,500,000 × 0.26 = 650,000.00 د.ج',
      'صافي الربح بعد الضريبة = 1,850,000.00 د.ج',
    ],
    keyNotesEn: [
      'Paid via three provisional installments (acomptes provisionnels) during the fiscal year plus a final liquidation balance.',
      'Mixed-activity companies must maintain separate accounting per rate category, or the highest rate may apply—verify CIDTA provisions.',
    ],
    keyNotesAr: [
      'تُسدد الضريبة عبر ثلاثة تسبيقات مؤقتة خلال السنة المالية بالإضافة إلى رصيد التصفية النهائي.',
      'الشركات ذات الأنشطة المختلطة يجب أن تمسك محاسبة منفصلة لكل معدل نشاط لتجنب تطبيق المعدل الأعلى؛ يرجى مراجعة نصوص CIDTA.',
    ],
  },
  {
    ruleId: 'irg-income',
    categoryEn: 'Direct Personal & Professional Income Tax',
    categoryAr: 'ضريبة مباشرة على دخل الأشخاص الطبيعيين',
    summaryEn:
      'IRG (Impôt sur le Revenu Global) applies to the total net annual income of individuals across categories such as salaries (IRG/Salaires), industrial/commercial profits, non-commercial profits, agricultural income, and investment/rental income.',
    summaryAr:
      'الضريبة على الدخل الإجمالي (IRG) تطبق على صافي الدخل السنوي الإجمالي للأشخاص الطبيعيين عبر فئات متعددة تشمل الأجور (IRG على الأجور)، الأرباح الصناعية والتجارية، المهن الحرة، وعوائد رؤوس الأموال والإيجارات.',
    scopeEn:
      'Salaries are withheld monthly at source by the employer according to the official progressive IRG scale (barème) published by the DGI, including statutory abatements.',
    scopeAr:
      'تُقتطع الضريبة على الأجور شهرياً من المنبع من قبل صاحب العمل وفق السلم التصاعدي الرسمي الصادر عن المديرية العامة للضرائب مع احتساب التخفيضات القانونية.',
    formulaEn: 'Progressive Bracket Sum or Withholding = Taxable Base × Bracket/Withholding Rate',
    formulaAr: 'حساب الشرائح التصاعدية أو الاقتطاع = الوعاء الخاضع × معدل الشريحة أو الاقتطاع',
    exampleTitleEn: 'Withholding Reference Example (15% Configurable Rate)',
    exampleTitleAr: 'مثال مرجعي للاقتطاع (بمعدل 15% قابل للتعديل)',
    exampleStepsEn: [
      'Taxable Income Base = 120,000.00 DZD',
      'Configured Reference Rate = 15%',
      'Calculated IRG = 120,000 × 0.15 = 18,000.00 DZD',
      'Net Disposable Amount = 102,000.00 DZD',
    ],
    exampleStepsAr: [
      'الوعاء الدخلي الخاضع للضريبة = 120,000.00 د.ج',
      'المعدل المرجعي المضبوط = 15%',
      'قيمة الضريبة المحسوبة (IRG) = 120,000 × 0.15 = 18,000.00 د.ج',
      'صافي المبلغ المتبقي = 102,000.00 د.ج',
    ],
    keyNotesEn: [
      'Salary exemptions (e.g., low-income thresholds) and family/disability abatements are governed by the official DGI barème.',
      'Always check whether a specific income category uses a flat withholding rate (retenue à la source libératoire) or the progressive annual scale.',
    ],
    keyNotesAr: [
      'تخضع الإعفاءات الخاصة بالأجور المنخفضة والتخفيضات العائلية للسلم الرسمي الصادر عن المديرية العامة للضرائب.',
      'تحقق دائماً مما إذا كان نوع الدخل يخضع لاقتطاع نسبي محرر من الضريبة أو للجدول التصاعدي السنوي.',
    ],
  },
  {
    ruleId: 'ifu-flat',
    categoryEn: 'Simplified Turnover Regime',
    categoryAr: 'النظام الضريبي المبسط على رقم الأعمال',
    summaryEn:
      'IFU (Impôt Forfaitaire Unique) is a simplified single tax replacing multiple taxes (such as IRG/IBS and TVA under the flat regime) for eligible small taxpayers and sole proprietors whose annual turnover falls below the statutory threshold.',
    summaryAr:
      'الضريبة الجزافية الوحيدة (IFU) هي ضريبة موحدة ومبسطة تحل محل عدة ضرائب بالنسبة لصغار المكلفين والمؤسسات الفردية التي لا يتجاوز رقم أعمالها السنوي السقف القانوني المحدد.',
    scopeEn:
      'Calculated directly on realized or forecast annual turnover. Taxpayers under IFU do not charge TVA on invoices and must observe the statutory turnover cap and minimum tax.',
    scopeAr:
      'تُحسب مباشرة على رقم الأعمال السنوي المحقق أو التقديري. لا يفوتر الخاضعون لنظام IFU الرسم على القيمة المضافة، مع ضرورة الالتزام بالسقف القانوني والحد الأدنى للضريبة.',
    formulaEn: 'IFU Due = Gross Turnover × IFU Rate (5% Goods / 12% Services — verify current caps)',
    formulaAr: 'الضريبة المستحقة = رقم الأعمال الإجمالي × معدل IFU (5% للسلع / 12% للخدمات — تحقق من السقف)',
    exampleTitleEn: 'Service Provider Turnover Example (12% IFU)',
    exampleTitleAr: 'مثال مقدم خدمات (بمعدل 12% IFU)',
    exampleStepsEn: [
      'Annual Taxable Turnover = 1,800,000.00 DZD',
      'Applicable Service IFU Rate = 12%',
      'Calculated IFU = 1,800,000 × 0.12 = 216,000.00 DZD',
    ],
    exampleStepsAr: [
      'رقم الأعمال السنوي الخاضع للضريبة = 1,800,000.00 د.ج',
      'معدل IFU للخدمات = 12%',
      'قيمة الضريبة الجزافية المحسوبة = 1,800,000 × 0.12 = 216,000.00 د.ج',
    ],
    keyNotesEn: [
      'Verify annual turnover ceilings (e.g., 8,000,000 DZD historical benchmark) and excluded activities in the latest Finance Law.',
      'A statutory minimum annual IFU payment applies even if calculated turnover tax is lower.',
    ],
    keyNotesAr: [
      'تحقق من سقف رقم الأعمال السنوي وقائمة الأنشطة المستثناة في آخر قانون مالية.',
      'يُفرض حد أدنى سنوي للضريبة الجزافية الوحيدة حتى لو كانت النسبة المحسوبة أقل من الحد القانوني.',
    ],
  },
  {
    ruleId: 'tap-reference',
    categoryEn: 'Historical / Statutory Reform Context',
    categoryAr: 'مرجع تاريخي وسياق الإصلاح الجبائي',
    summaryEn:
      'TAP (Taxe sur l’Activité Professionnelle) was historically levied on monthly turnover (typically 2% or 1.5% with rebates). Under the Algerian Finance Law 2024, TAP was repealed to lighten the fiscal burden on businesses, alongside local tax restructuring.',
    summaryAr:
      'كان الرسم على النشاط المهني (TAP) يُفرض تاريخياً على رقم الأعمال الشهري. وبموجب قانون المالية الجزائري لسنة 2024، تم إلغاء هذا الرسم لتخفيف العبء الجبائي على المؤسسات مع إعادة هيكلة بعض الرسوم المحلية.',
    scopeEn:
      'Retained in TaxCollect solely as a configurable reference for historical invoice audits (pre-2024) or academic comparisons in university finance courses.',
    scopeAr:
      'تم إدراجه في TaxCollect كمرجع قابل للتعديل لمراجعة الفواتير التاريخية قبل 2024 أو للمقارنات الأكاديمية في مشاريع المحاسبة والمالية.',
    formulaEn: 'Current Standard: 0% (Repealed)  |  Historical Audit: Turnover HT × Historical Rate',
    formulaAr: 'الوضع الحالي: 0% (ملغى)  |  للمراجعة التاريخية: رقم الأعمال HT × المعدل التاريخي',
    exampleTitleEn: 'Historical Comparison Example',
    exampleTitleAr: 'مثال للمقارنة التاريخية',
    exampleStepsEn: [
      'Monthly Turnover HT = 500,000.00 DZD',
      'Post-2024 TAP Rate = 0% → 0.00 DZD',
      'Pre-2024 Reference (2%) = 500,000 × 0.02 = 10,000.00 DZD',
    ],
    exampleStepsAr: [
      'رقم الأعمال الشهري خارج الرسم = 500,000.00 د.ج',
      'معدل TAP بعد 2024 = 0% ← 0.00 د.ج',
      'المرجع التاريخي قبل 2024 (2%) = 500,000 × 0.02 = 10,000.00 د.ج',
    ],
    keyNotesEn: [
      'Verify local solidarity tax (TLS) or sector-specific levies introduced after TAP repeal with your tax advisor or DGI.',
      'Do not apply historical TAP rates to current-year standard commercial invoices.',
    ],
    keyNotesAr: [
      'تحقق من الرسوم المحلية البديلة (مثل TLS) أو الرسوم القطاعية الخاصة لدى مصالح الضرائب.',
      'لا تطبق معدلات TAP التاريخية على الفواتير التجارية الاعتيادية للسنة الحالية.',
    ],
  },
  {
    ruleId: 'custom-tax',
    categoryEn: 'Stamp Duty & Custom Rules',
    categoryAr: 'طابع الدمغة والقواعد المخصصة',
    summaryEn:
      'Algerian tax practice also includes Droits de Timbre (stamp duty on cash payments and legal instruments) and specialized sectoral levies. Because stamp duty brackets and caps change across Finance Laws, TaxCollect provides a configurable custom rule.',
    summaryAr:
      'تتضمن الممارسة الجبائية الجزائرية أيضاً طابع الدمغة (خاصة على المدفوعات النقدية والوثائق) ورسوماً قطاعية خاصة. ونظراً لتغير شرائح وأسقف طابع الدمغة عبر قوانين المالية، يوفر TaxCollect قاعدة مخصصة قابلة للتعديل.',
    scopeEn:
      'Configure any custom rate and effective date in Settings or directly in the Smart Calculator.',
    scopeAr:
      'يمكنك ضبط أي معدل مخصص وتاريخ سريان في صفحة الإعدادات أو مباشرة داخل الحاسبة الذكية.',
    formulaEn: 'Tax = Base × (Configured Rate / 100)',
    formulaAr: 'قيمة الرسم = الأساس × (المعدل المضبوط ÷ 100)',
    exampleTitleEn: 'Custom Stamp Reference (1%)',
    exampleTitleAr: 'مثال مرجعي لرسم مخصص (1%)',
    exampleStepsEn: [
      'Cash Payment Base = 50,000.00 DZD',
      'Configured Stamp Rate = 1%',
      'Calculated Stamp = 50,000 × 0.01 = 500.00 DZD (Subject to statutory min/max verification)',
    ],
    exampleStepsAr: [
      'أساس الدفع النقدي = 50,000.00 د.ج',
      'معدل الطابع المضبوط = 1%',
      'الرسم المحسوب = 50,000 × 0.01 = 500.00 د.ج (يخضع للتحقق من الحد الأدنى والأقصى القانوني)',
    ],
    keyNotesEn: [
      'Check cash-payment stamp duty minimum/maximum caps in the latest Code du Timbre.',
      'Keep effective dates updated whenever a new Finance Law enters into force on January 1st.',
    ],
    keyNotesAr: [
      'راجع الحد الأدنى والأقصى لطابع الدمغة على الدفع نقداً في قانون الطابع الساري.',
      'قم بتحديث تواريخ السريان كلما دخل قانون مالية جديد حيز التنفيذ.',
    ],
  },
];
