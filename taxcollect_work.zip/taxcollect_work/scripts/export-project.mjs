import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const ROOT_FILES = [
  '.env.example',
  '.gitignore',
  'index.html',
  'metadata.json',
  'package.json',
  'server.ts',
  'tsconfig.json',
  'vite.config.ts',
];

function addDirectoryToZip(zip, dirPath, zipBasePath) {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name.startsWith('.env')) {
      continue;
    }
    const fullPath = path.join(dirPath, entry.name);
    const relZipPath = path.posix.join(zipBasePath, entry.name);
    if (entry.isDirectory()) {
      addDirectoryToZip(zip, fullPath, relZipPath);
    } else if (entry.isFile()) {
      zip.file(relZipPath, fs.readFileSync(fullPath));
    }
  }
}

export async function buildProjectZipBuffer() {
  const zip = new JSZip();

  for (const fileName of ROOT_FILES) {
    const filePath = path.join(ROOT_DIR, fileName);
    if (fs.existsSync(filePath)) {
      zip.file(fileName, fs.readFileSync(filePath));
    }
  }

  const srcDir = path.join(ROOT_DIR, 'src');
  if (fs.existsSync(srcDir)) {
    addDirectoryToZip(zip, srcDir, 'src');
  }

  const publicDir = path.join(ROOT_DIR, 'public');
  if (fs.existsSync(publicDir)) {
    addDirectoryToZip(zip, publicDir, 'public');
  }

  const selfScript = path.join(ROOT_DIR, 'scripts', 'export-project.mjs');
  if (fs.existsSync(selfScript)) {
    zip.file('scripts/export-project.mjs', fs.readFileSync(selfScript));
  }

  return zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });
}

// Run directly as a CLI script: `node scripts/export-project.mjs`
if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  const outPath = path.join(ROOT_DIR, 'TaxCollect_Project.zip');
  buildProjectZipBuffer()
    .then((buf) => {
      fs.writeFileSync(outPath, buf);
      console.log(`Bundle created successfully: ${outPath} (${(buf.length / 1024).toFixed(1)} KB)`);
    })
    .catch((err) => {
      console.error('Failed to bundle TaxCollect project:', err);
      process.exit(1);
    });
}
